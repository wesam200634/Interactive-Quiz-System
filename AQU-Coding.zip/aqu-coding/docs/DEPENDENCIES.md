# Dependency inventory

The project compiles with the JDK tools directly. Everything under `src/main/java`, the distribution launcher, the test suites, and the eight reference solutions is Java. The SQL and CSS resources are loaded from the application JAR.

| Component | Version and location | Use |
|---|---|---|
| JDK | 17 or later, supplied by the user | Java application runtime, compiler, archive tool, and source-file launcher |
| OpenJFX | 17.0.16 under lib/linux, lib/win, lib/mac, and lib/mac-aarch64 | Platform-specific base, graphics, and controls |
| H2 | 2.3.232 under lib/common | Pure-Java embedded JDBC database |
| JUnit Platform Console Standalone | 1.11.4 under lib/test | Test discovery, assertions, and execution |
| TestFX Monocle | 17.0.10 under lib/test | Headless JavaFX glass platform for automated UI checks |
| Docker | Local Linux-container engine and CLI, supplied by the user | Isolated compilers and submitted programs |
| Judge images | judge/images-linux-amd64.tar.gz and judge/Dockerfile | Java 17, Python 3.12, and C++17 on Alpine Linux |

The platform JARs were obtained from Maven Central and compared with their published checksums. Bundled SHA-256 digests are in `lib/SHA256SUMS`. From the project root, Linux users can run `sha256sum -c lib/SHA256SUMS`. On macOS use `shasum -a 256 -c lib/SHA256SUMS`.

## Local judge toolchains

The archive contains a Docker image export for Linux amd64. Windows x64 and Intel macOS use these images through Docker’s Linux VM. On an ARM64 Docker engine, the launcher uses the multiarchitecture upstream Java and Python tags and builds C++ locally. This one-time ARM setup needs internet access. Subsequent judging is local.

| Docker tag | Offline image ID |
|---|---|
| amazoncorretto:17-alpine | fcb83dd6553a828e3b6056eada289351f18adfdc3a3106805f628c8ac070ad53 |
| python:3.12-alpine | 4076016aea5420e5c87eb52280edfc527ace1ce31dc1c9288b1cc4ef9a0e8905 |
| aqu-cpp:1 | ddb181a587c6d85600245424138a91753afc08a3c1b33ccb5fe1f8a33a6c1a60 |

The C++ image uses Alpine 3.22 and its g++ and musl-dev packages. The offline image IDs identify the tested binaries. Fresh network pulls and package-index builds can pick up newer patch releases under the same tags.

## Third-party notices and upstream sources

The libraries and toolchains are distributed under their respective upstream licenses and warranty terms. Included project notices are in [licenses](licenses/). The JUnit standalone archive and container distributions retain their bundled third-party notices.

- OpenJFX and the Monocle classes use GPL v2 with the Classpath exception where designated. [OpenJFX 17 update source](https://github.com/openjdk/jfx17u) · [TestFX Monocle](https://github.com/TestFX/Monocle)
- H2 is available under MPL 2.0 or EPL 1.0. [H2 source for 2.3.232](https://github.com/h2database/h2database/tree/version-2.3.232)
- JUnit uses EPL 2.0 and includes separately licensed components. [JUnit 5 source](https://github.com/junit-team/junit5)
- The judge images include Amazon Corretto, CPython, GNU C++, musl, and Alpine packages. [Corretto image sources](https://github.com/corretto/corretto-docker) · [Python image sources](https://github.com/docker-library/python) · [Alpine package sources](https://gitlab.alpinelinux.org/alpine/aports) · [GCC source](https://gcc.gnu.org/git.html)
