# User guide

## Student practice

Open **Problems** and enter part of a title, choose a topic, or choose a difficulty. Filters combine. Clear the search and select **All topics** and **All levels** to restore the full list. Double-click a row or select it and choose **Open problem**. Each record has a stable identifier, so problems with identical titles retain their own examples and attempts.

Read the statement, input rules, output rules, and examples. Expand **Hint** for a clue or **Solution explanation** for the approach. **Save problem** adds the problem to your bookmarks. **Remove from saved** removes your bookmark. **Learning path** opens the same problems in three stages from foundations to competition preparation.

Choose Java 17, C++17, or Python 3.12 in the editor. Read standard input, write the answer to standard output, and omit interactive prompts. Java submissions use a class named `Main` in the default package. Click **Submit** and wait for the result. Closing the window and switching accounts are disabled during checking so that the result returns to its submitting user. Copy any draft you wish to keep before navigating away. Saved attempts include the submitted source.

| Verdict | Meaning |
|---|---|
| Accepted | Every required output matched. |
| Wrong Answer | The program finished and produced a different output on a required case. |
| Compilation Error | The compiler or Python syntax check rejected the source. Review the displayed diagnostic. |
| Runtime Error | The program failed during execution. |
| Checking failed | A resource limit, missing runtime, interrupted check, or judge error prevented completion. |

The checker normalizes line endings and ignores trailing whitespace at the end of the complete output. It preserves internal whitespace and line order. Compiler diagnostics and standard error are kept separate from output comparison. Hidden expected answers stay in the desktop process.

**Progress** shows distinct solved problems, attempts by topic, recurring unsuccessful results, and the full submission history. Expand an attempt to inspect its code and feedback. An attempt saved after a checking failure remains identifiable by that verdict. A database save failure produces an explicit warning and leaves the attempt out of history.

## Contests and teams

Open **Contests** to review each round’s problem set and duration. **Start or resume** starts your personal clock on the first visit and reloads its original deadline thereafter. Open a problem from inside that round to submit a contest attempt. Submitting from **Problems** creates an ordinary practice attempt. Eligibility is checked when a contest submission is received. A submission received before the deadline can finish judging afterward.

Closing the application does not pause the clock. Expired rounds retain prior attempts and reject new contest entries. The local computer’s clock supplies the time. **Teams** lists each practice group and marks your memberships as **Joined**.

## Coaches and administrators

In **Problem library**, choose **New problem** or select an existing problem and choose **Edit selected problem**. Supply the statement, classification, examples, judging tests, hint, and explanation. Each pair has separate multiline input and expected-output fields. At least one public example and one required judge case are necessary. A case may use empty input or empty output. A completely empty pair prompts for correction. Save publishes all of the changes together. The form keeps your entries visible if validation or saving fails.

Use **Student review** to choose a current student and inspect their solved problems, attempts, topic counts, and recurring errors. Under **Accounts**, administrators can assign Student, Coach, or Administrator. Changes apply at the account’s next sign-in. At least one administrator must remain. **Log out** clears the active session for every role.

## Troubleshooting

| Symptom | What to check |
|---|---|
| Java cannot find the launcher or libraries | Extract the complete ZIP and run commands from the directory containing README.md, scripts, and lib. |
| Missing javac or unsupported release | Put a full JDK 17+ on PATH and check both java and javac versions. |
| Cannot open a Linux window | Run in a graphical desktop session with GTK 3 installed. |
| Docker image or daemon error | Start the local Docker engine, use Linux containers, confirm `docker info` works, and rerun `java scripts/Studio.java judge-setup`. |
| Cannot open or save the database | Close another instance using the same file, confirm disk space and data-folder permissions, or start with a separate writable database path. |
| A large case times out | Check the algorithm and input handling. Each case gets three seconds of execution time after compilation. |
| A new role is missing | Log out and sign in again with the updated account. |
