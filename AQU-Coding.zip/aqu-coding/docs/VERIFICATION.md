# Verification and requirements coverage

Run the full suite with a JDK 17+ and a running local Docker engine.

```sh
java scripts/Studio.java judge-setup
java scripts/Studio.java test
```

Tests create temporary H2 databases. The suite exercises the actual JavaFX controls, the service API, the JDBC persistence layer, and each real language toolchain. WorkflowTest substitutes a deterministic judge when the question under test is a database, timing, or authorization rule. JudgeTest, SeedContentTest, and the JavaFX end-to-end test invoke DockerJudge. See [test results](TEST-RESULTS.txt) for the executed run.

## Traceability

The stable identifiers below refer to the supplied Requirements Specification.

| Requirements | Implemented behavior | Verification |
|---|---|---|
| UR-01–02, UR-14–15 · SR-01–03, SR-18, SR-27 · NFR-05–06 | Registration, unique university numbers, protected credentials, role-specific screens, permission checks, role changes on sign-in, and logout | WorkflowTest checks duplicate registration, salts and digests, session clearing, unauthorized service calls, and promotion. DesktopTest registers users and exercises all three roles. |
| UR-03–04, UR-07, UR-09 · SR-04–05, SR-10, SR-12–13, SR-20 · NFR-08–09 · DR-02–03, DR-07, DR-10 | Combined filters, empty results, exact record identity, public examples, hints, explanations, bookmarks, and ordered practice stages | Service checks cover filtering, removal, missing IDs, identical titles, and bookmark ownership. DesktopTest follows filtered, saved, and learning-path screens. |
| UR-05–06 · SR-06–08, SR-23 · NFR-03, NFR-07, NFR-10 · DR-04–05, DR-09 | Background judging of nonempty code in Java, C++, or Python with genuine output comparison, bounded execution, and feedback | JudgeTest runs accepted solutions in all three languages, wrong answers, compiler errors, execution failures, timeout, and excessive output. DesktopTest submits Java through the editor. |
| UR-08, UR-13 · SR-09, SR-11, SR-16, SR-24 · DR-06, DR-11 | All saved attempts retain ownership, source, verdict, and time. Progress counts each solved ID once. Coach review includes topics and errors. | WorkflowTest uses repeated accepted submissions, identity checks, and reopened storage. DesktopTest opens student and coach views from the same records. |
| UR-10 · SR-14, SR-25 · DR-08, DR-12 | Per-student timed rounds, persisted deadlines, contest problem checks, and eligible attempt linkage | WorkflowTest uses a controlled clock and checks the exact deadline, resumption, wrong-contest requests, a second user, and preservation of earlier attempts. |
| UR-11 · SR-17, SR-26 | Team membership with a unique student/team pair | WorkflowTest checks duplicate joins and visibility for a different account. DesktopTest joins through the UI. |
| UR-12 · SR-15, SR-21–22 · NFR-14 · DR-01 | Validated coach editing, separate examples and tests, transactional updates, and new content on later opens | DesktopTest creates and edits a problem and checks form retention. WorkflowTest forces a child-row save failure and verifies rollback. SeedContentTest runs eight independent Java reference programs against the published examples and all required cases. |
| SR-19, SR-28 · NFR-04, NFR-11–12 | Persistence across navigation and restart, explicit save failures, and coherent history | WorkflowTest reopens a file database, injects account/problem/submission write failures, and checks stored state. DesktopTest recreates the application and reopens student data. |
| NFR-01–02 | Find and open a problem within five minutes for a newcomer. Return filtered data from 1,000 problems within three seconds on the specified hardware. | The suite measures query plus row mapping for a 1,000-record fixture on the test host. The procedure below covers student usability and target-hardware timing. Those two stakeholder/hardware trials require separate observation. |
| NFR-13, NFR-15–17 | Java 17+, JavaFX, JDBC, local execution, stable IDs, and repeatable demonstration | Java build and native launch, architecture document, this matrix, and the following checklist. |

## Repeatable demonstration

Use a separate demo database to keep personal practice records intact. Start with `java scripts/Studio.java run ./demo-data/practice`. The walkthrough assumes a new database.

1. Create an administrator. Register two further accounts, one for a student and one for a coach. Try a duplicate university number and an incorrect password. Verify that both are rejected.
2. Sign in as administrator and promote the coach. Log out and sign in as that coach. Verify that **Problem library** and **Student review** open.
3. As the student, filter for **Arrays** and **Easy**. Open **Array Total**. Save it, reveal the hint, return through **Saved problems**, and verify its title, input rules, and example.
4. Open **First Sum**. Submit an empty editor, then Java code that always prints 20. Expect a validation message then Wrong Answer. Submit the Java solution in the README twice. Expect one solved problem and three persisted attempts.
5. Open **Progress** and inspect an earlier attempt’s code. Close and reopen the app, sign in again, and confirm the history and bookmark. Join a team and confirm the button changes to **Joined**.
6. Start **First Steps Sprint** and submit inside the round. Check the contest label in history. Reopen the round and confirm its deadline stays fixed. The automated deadline test performs the expiry check immediately with a controlled clock.
7. As coach, start a new problem. Omit the topic and attempt to save. Confirm the title remains editable. Enter a complete example and hidden test, save, then edit the hidden expected output. Reopen the saved problem as a student and verify that the revised test affects the verdict.
8. As coach, open **Student review** and verify the student’s solved list and results. Log out. Verify that signing in as the student returns to the practice area.
9. For the usability trial, provide a registered student account to a first-time participant and time how long they take to sign in, filter, and open a named problem. Record elapsed time and whether help was required. For the hardware target, repeat the 1,000-problem test on a two-core machine with 4 GB RAM and record end-to-end screen response as well as query time.
