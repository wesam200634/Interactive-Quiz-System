# Architecture and data model

AQU Coding follows the supplied layered desktop design. JavaFX controllers translate user actions into service calls. Domain records carry typed results, the JDBC layer handles transactions, and the local judge evaluates source code. The database is embedded H2. The application includes a graphical first-run administrator setup and uses no preset passwords.

```mermaid
flowchart TD
    UI[JavaFX desktop] --> A[Accounts]
    UI --> P[Problems]
    UI --> S[Practice]
    P --> A
    S --> A
    A --> D[JDBC transactions]
    P --> D
    S --> D
    D --> H[(Local H2 file)]
    S --> J[DockerJudge]
    J --> T[One isolated local container per case]
```

| Component | Responsibilities |
|---|---|
| Desktop, StudyViews, StaffViews, Widgets | Sign-in and role navigation, editable forms, timers, editor, feedback, and progress rendering. |
| Accounts | Registration, one-time bootstrap, password verification, role checks, session identity, and role changes. Each active session retains the role established at sign-in. |
| Problems | Stable problem identifiers, combined filters, bookmarks, validation, and atomic publication of text, examples, and hidden tests. |
| Practice | Student-specific contest windows, team membership, authorization of history reads, and submission evaluation and persistence. |
| Judge, Language, DockerJudge | Language commands, container lifecycle, deadline and output bounds, diagnostics, and host-side comparison. The Judge interface allows deterministic failure tests. |
| Database | Prepared statements, binding, transaction commit and rollback, schema initialization, and resource cleanup. |

## Submission path

1. The editor captures the selected problem, language, source, and optional contest identifier. It displays checking feedback immediately and starts a background JavaFX task.
2. Practice checks the signed-in student, nonempty source, problem, and contest membership/deadline. It reads the problem’s stored judging cases.
3. DockerJudge sends source and one input to a fresh local container. It compiles the source inside that container, runs it, and compares stdout to the expected answer in Java. The first failure terminates checking.
4. Practice writes the timestamp captured at submission, owner, problem, language, source, contest association, verdict, and feedback in a transaction. A receipt distinguishes the verdict from successful storage.
5. Progress derives solved problems from unique problem IDs with saved Accepted attempts. The coach and student displays use the same stored records.

## Relational structure

| Table | Identity and relationships |
|---|---|
| accounts | Generated ID and unique university number stored as text to preserve leading zeros. Role is constrained to three permitted values. |
| setup_state, app_meta | One-time administrator bootstrap and starter-data version. |
| problems, cases | A problem owns public examples and hidden judge pairs. The composite key includes the problem, case kind, and position. |
| saved, memberships | Unique pairs of account/problem and account/team. Duplicate saves and joins are idempotent. |
| teams | Named local practice groups. |
| contests, contest_problems | Duration and many-to-many problem association. |
| contest_sessions | Student/contest key with stored start and deadline. |
| attempts | A student and problem own each attempt. Optional composite foreign keys tie contest attempts to the correct session and contest problem. |

Accounts use PBKDF2-HMAC-SHA256 with a fresh 16-byte salt, 210,000 iterations, and constant-time digest comparison. The local operator controls the database file and Docker engine. Protect the operating-system account and its backups accordingly.

## Execution limits

The judge uses a local Linux-container Docker engine. Submissions run as UID 65534 with a read-only root filesystem, no network, no host mounts, all capabilities dropped, and no privilege escalation. Each case gets private temporary storage, one CPU, 384 MiB memory, and at most 80 processes. Java programs use a 96 MiB maximum heap. The checker uses a 12-second compile limit, a three-second execution limit, and a 25-second outer bound per case. Each output stream is limited to 64 KiB. The outer checker attempts forced container removal when interrupted or over limit.

Each case recompiles in a fresh environment, keeping earlier test executions isolated. After the one-time setup, judging uses local images with `--pull=never`. Normal app use requires no network service. The packaged configuration targets personal or supervised single-computer practice.

## Source documents

The Requirements Specification, Architectural Design Report, and System Modeling Report in [specifications](specifications/) describe the first release. The competitive-programming benchmark provided course context and longer-term ideas for rankings and shared competition. The Chapter 1 homework discusses software engineering generally. This implementation follows the first-release desktop specification.
