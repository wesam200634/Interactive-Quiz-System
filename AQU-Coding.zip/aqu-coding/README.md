# AQU Coding

A Java 17 desktop application for competitive programming practice at Al-Quds University. Students solve problems against hidden tests, coaches maintain the problem bank, and administrators manage local accounts. A new installation includes eight problems from fundamentals to dynamic programming, two timed contests, and three training teams.

![AQU Coding problem bank on Linux](docs/problem-bank.png)

## Run the project

1. Install a **JDK 17 or later** matching your desktop architecture. In a terminal, check that `java -version` and `javac -version` report version 17 or later. Linux desktops also need GTK 3.
2. Install and start **Docker Engine** or **Docker Desktop** using local Linux containers. The desktop application and its database run directly on your computer. Docker runs student submissions.
3. Extract the whole ZIP. Open a terminal in the `aqu-coding` directory that contains this README.
4. Run these commands. They work in PowerShell, Command Prompt, and a macOS or Linux terminal.

```sh
java scripts/Studio.java judge-setup
java scripts/Studio.java run
```

This compact edition includes the Windows x64 libraries. Judge setup requires internet access once to download Java and Python images and build the C++ image. Start Docker Desktop in Linux container mode before setup.

## First session

- On first launch, create the local **administrator** account. Choose its university number and password. Keep those credentials for role management.
- At sign-in, choose **Create student account** to register a separate practice account. Sign in with that account to open the problem bank.
- To create a coach, register another student account, sign in as administrator, select that account under **Accounts**, set **Coach**, and click **Save role**. The coach can sign in to **Problem library** and **Student review**.
- To try the judge, open **First Sum**, leave **Java** selected, paste the program below, and click **Submit**. An accepted result appears in **Progress**. Submit again to see two attempts and one solved problem.

```java
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println(input.nextInt() + input.nextInt());
    }
}
```

## Build and test

```sh
java scripts/Studio.java build
java scripts/Studio.java test
```

Build compiles the Java sources with `--release 17` and writes `dist/aqu-coding.jar`. Run build after editing the source. Test rebuilds the application and runs the JUnit suite, including real compiler executions and a headless JavaFX workflow. Prepare the judge images first. Tests use temporary databases. The eight reference submissions under `src/test/resources/solutions` are independent Java programs compiled by the judge.

## Project layout

```text
aqu-coding/
  src/main/java/edu/aqu/coding/
    Main.java         JavaFX application entry point
    ui/               Role-specific views and event controllers
    model/            Accounts, problems, cases, attempts, and verdicts
    service/          Authorization, authoring, contests, and progress
    judge/            Local Docker process execution and output checking
    data/             Embedded JDBC connections and transaction helpers
  src/main/resources/ Schema, starter content, and JavaFX stylesheet
  src/test/           JUnit workflow, judge, UI, and content tests
  dist/               Ready-to-run application JAR
  lib/                Platform libraries, test dependencies, and checksums
  judge/              C++ Dockerfile and offline x64 judge images
  scripts/            Java build, setup, run, and test launcher
  docs/               User guide, design, verification, and specifications
```

## Local data and recovery

AQU Coding creates `.aqu-coding/practice.mv.db` under the current operating-system user’s home directory. Closing and reopening the application preserves accounts, submissions, bookmarks, contest clocks, and team membership. Use one application instance per database. Protect the data folder with the computer’s normal account permissions.

For a backup, close the application and copy the `.mv.db` file to a private location. To open a copy, pass its path **without** the `.mv.db` extension. This example opens a separate database for demonstrations.

```sh
java scripts/Studio.java run ./demo-data/practice
```

## Documentation

- [User guide and troubleshooting](docs/USER-GUIDE.md)
- [Architecture and data model](docs/ARCHITECTURE.md)
- [Requirements coverage and demonstration checklist](docs/VERIFICATION.md)
- [Executed test results](docs/TEST-RESULTS.txt)
- [Dependency inventory and licenses](docs/DEPENDENCIES.md)
