package edu.aqu.coding.ui;

import static edu.aqu.coding.ui.Widgets.*;

import edu.aqu.coding.model.Models.*;
import edu.aqu.coding.service.*;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.*;

public final class Desktop {
    final Accounts auth;
    final Problems problems;
    final Practice practice;
    final Stage stage;
    final BorderPane root = new BorderPane();
    final StudyViews study;
    final StaffViews staff;
    private final Scene scene = new Scene(root, 1100, 730);
    private final Label notice = label("", "notice");
    private final Map<String, Button> links = new LinkedHashMap<>();
    private VBox sidebar, body;
    private Timeline timer;
    private boolean busy;

    public Desktop(Stage stage, Accounts auth, Problems problems, Practice practice) {
        this.stage = stage;
        this.auth = auth;
        this.problems = problems;
        this.practice = practice;
        study = new StudyViews(this);
        staff = new StaffViews(this);
    }

    public void show() {
        scene.getStylesheets()
                .add(
                        Objects.requireNonNull(getClass().getResource("/studio.css"))
                                .toExternalForm());
        stage.setTitle("AQU Coding · Al-Quds University");
        stage.setScene(scene);
        stage.setMinWidth(820);
        stage.setMinHeight(580);
        stage.setOnCloseRequest(
                e -> {
                    if (busy) {
                        e.consume();
                        message("Wait for the current submission to finish.");
                    }
                });
        gate(auth.needsSetup() ? "setup" : "login");
        stage.show();
    }

    Button action(String text, String style, Runnable r) {
        return button(text, style, () -> guard(r));
    }

    void guard(Runnable r) {
        try {
            r.run();
        } catch (RuntimeException ex) {
            message(ex.getMessage() == null ? "The operation could not finish." : ex.getMessage());
        }
    }

    void message(String msg) {
        notice.setText(msg);
        visible(notice, true);
    }

    private void clearNotice() {
        notice.setText("");
        visible(notice, false);
    }

    void gate(String mode) {
        stopClock();
        links.clear();
        root.setLeft(null);
        root.setBottom(null);
        clearNotice();
        boolean login = mode.equals("login"), setup = mode.equals("setup");
        var number = field("University number", "number");
        var name = field("Full name", "name");
        var pass = new PasswordField();
        pass.setId("password");
        pass.setPromptText("Password");
        var form =
                box(
                        14,
                        label(
                                setup
                                        ? "First-time setup"
                                        : login ? "Welcome back" : "Create an account",
                                "title"),
                        label(
                                setup
                                        ? "Create the administrator account for this computer."
                                        : login
                                                ? "Sign in to your training workspace."
                                                : "Register for a local student account.",
                                "muted"));
        if (!login) form.getChildren().add(fieldGroup("Full name", name));
        form.getChildren()
                .addAll(
                        fieldGroup("University number", number),
                        fieldGroup(login ? "Password" : "Password · 8 characters minimum", pass));
        var submit =
                action(
                        setup ? "Create administrator" : login ? "Sign in" : "Create account",
                        "primary",
                        () -> {
                            if (login) {
                                auth.login(number.getText(), pass.getText());
                                shell();
                            } else {
                                if (setup)
                                    auth.setup(name.getText(), number.getText(), pass.getText());
                                else
                                    auth.register(name.getText(), number.getText(), pass.getText());
                                gate("login");
                                message("Account created. Sign in with your university number.");
                            }
                        });
        submit.setId("authenticate");
        submit.setDefaultButton(true);
        pass.setOnAction(
                event -> {
                    event.consume();
                    submit.fire();
                });
        submit.setMaxWidth(Double.MAX_VALUE);
        form.getChildren().add(submit);
        if (!setup)
            form.getChildren()
                    .add(
                            action(
                                    login ? "Create student account" : "Back to sign in",
                                    "link",
                                    () -> gate(login ? "register" : "login")));
        form.getChildren().add(notice);
        form.setMaxWidth(400);
        form.setMaxHeight(Region.USE_PREF_SIZE);
        form.setPadding(new Insets(25));
        var brand =
                box(
                        16,
                        label("AL-QUDS UNIVERSITY", "eyebrow"),
                        label("AQU Coding", "brand-title"),
                        network(),
                        label("Competitive programming studio", "light-copy"));
        brand.getStyleClass().add("brand-panel");
        brand.setAlignment(Pos.CENTER_LEFT);
        brand.setPrefWidth(350);
        var right = new StackPane(form);
        HBox.setHgrow(right, Priority.ALWAYS);
        root.setCenter(new HBox(brand, right));
        Platform.runLater(
                () -> {
                    if (login) number.requestFocus();
                    else name.requestFocus();
                });
    }

    private static Pane network() {
        var pane = new Pane();
        pane.setPrefSize(240, 120);
        pane.setMaxHeight(120);
        double[][] p = {{3, 68}, {55, 28}, {110, 85}, {160, 40}, {217, 13}, {223, 90}};
        int[][] edges = {{0, 1}, {0, 2}, {1, 2}, {1, 3}, {2, 3}, {3, 4}, {3, 5}, {2, 5}};
        for (int[] e : edges) {
            var a = p[e[0]];
            var b = p[e[1]];
            var line = new Line(a[0], a[1], b[0], b[1]);
            line.setStroke(Color.web("#498380"));
            pane.getChildren().add(line);
        }
        for (var a : p) pane.getChildren().add(new Circle(a[0], a[1], 5, Color.web("#e1bd78")));
        return pane;
    }

    private void shell() {
        clearNotice();
        links.clear();
        var user = auth.require();
        sidebar =
                box(6, label("AQU Coding", "wordmark"), label("Al-Quds University", "light-copy"));
        sidebar.setPrefWidth(206);
        sidebar.getStyleClass().add("sidebar");
        var nav = box(4);
        nav.setPadding(new Insets(28, 0, 0, 0));
        sidebar.getChildren().add(nav);
        switch (user.role()) {
            case Student -> {
                nav(nav, "Problems", study::bank);
                nav(nav, "Learning path", study::path);
                nav(nav, "Saved problems", study::saved);
                nav(nav, "Progress", () -> study.progress(user.id(), false));
                nav(nav, "Contests", study::contests);
                nav(nav, "Teams", study::teams);
            }
            case Coach -> {
                nav(nav, "Problem library", staff::library);
                nav(nav, "Student review", staff::students);
            }
            case Administrator -> nav(nav, "Accounts", staff::accounts);
        }
        Region push = new Region();
        VBox.setVgrow(push, Priority.ALWAYS);
        sidebar.getChildren()
                .addAll(
                        push,
                        label(user.name(), "sidebar-name"),
                        label(user.role().name(), "light-copy"),
                        action(
                                "Log out",
                                "nav-button",
                                () -> {
                                    auth.logout();
                                    gate("login");
                                }));
        root.setLeft(sidebar);
        root.setBottom(notice);
        links.values().iterator().next().fire();
    }

    private void nav(VBox nav, String title, Runnable open) {
        Button b = action(title, "nav-button", open);
        b.setMaxWidth(Double.MAX_VALUE);
        links.put(title, b);
        nav.getChildren().add(b);
    }

    VBox page(String active, String title, String subtitle) {
        stopClock();
        clearNotice();
        links.forEach(
                (k, b) -> {
                    b.getStyleClass().remove("selected");
                    if (k.equals(active)) b.getStyleClass().add("selected");
                });
        body = box(17);
        if (!active.equalsIgnoreCase(title))
            body.getChildren().add(label(active.toUpperCase(Locale.ROOT), "kicker"));
        body.getChildren().add(label(title, "title"));
        if (!subtitle.isBlank()) body.getChildren().add(label(subtitle, "muted"));
        body.getStyleClass().add("page");
        root.setCenter(scroll(body));
        return body;
    }

    void setBusy(boolean value) {
        busy = value;
        sidebar.setDisable(value);
    }

    void clock(long deadline, Label display) {
        stopClock();
        Runnable tick =
                () -> {
                    long ms = deadline - System.currentTimeMillis();
                    long seconds = Math.max(0, (ms + 999) / 1000);
                    display.setText(
                            ms <= 0
                                    ? "Time expired · contest closed"
                                    : String.format(
                                            "Time remaining   %02d:%02d",
                                            seconds / 60, seconds % 60));
                };
        tick.run();
        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> tick.run()));
        timer.setCycleCount(Animation.INDEFINITE);
        timer.play();
    }

    private void stopClock() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
    }
}
