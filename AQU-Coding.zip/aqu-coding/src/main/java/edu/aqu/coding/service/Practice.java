package edu.aqu.coding.service;

import static edu.aqu.coding.data.Database.*;

import edu.aqu.coding.data.Database;
import edu.aqu.coding.judge.*;
import edu.aqu.coding.model.Models.*;

import java.time.Clock;
import java.util.*;

public final class Practice {
    private final Database db;
    private final Accounts auth;
    private final Judge judge;
    private final Clock clock;

    public Practice(Database db, Accounts auth, Judge judge, Clock clock) {
        this.db = db;
        this.auth = auth;
        this.judge = judge;
        this.clock = clock;
    }

    public List<Contest> contests() {
        auth.require(Role.Student);
        return db.transaction(
                c ->
                        list(
                                c,
                                "SELECT * FROM contests ORDER BY id",
                                r ->
                                        new Contest(
                                                r.getLong("id"),
                                                r.getString("title"),
                                                r.getInt("minutes"))));
    }

    public long start(Contest contest) {
        long user = auth.require(Role.Student).id();
        return db.transaction(
                c -> {
                    var durations =
                            list(
                                    c,
                                    "SELECT minutes FROM contests WHERE id=? FOR UPDATE",
                                    r -> r.getInt(1),
                                    contest.id());
                    if (durations.isEmpty())
                        throw new IllegalArgumentException("Contest no longer exists.");
                    var existing =
                            list(
                                    c,
                                    "SELECT deadline FROM contest_sessions WHERE user_id=? AND"
                                            + " contest_id=?",
                                    r -> r.getLong(1),
                                    user,
                                    contest.id());
                    if (!existing.isEmpty()) return existing.get(0);
                    long started = clock.millis(), deadline = started + durations.get(0) * 60_000L;
                    update(
                            c,
                            "INSERT INTO contest_sessions VALUES(?,?,?,?)",
                            user,
                            contest.id(),
                            started,
                            deadline);
                    return deadline;
                });
    }

    public List<Item> contestProblems(long contest) {
        auth.require(Role.Student);
        return db.transaction(
                c ->
                        list(
                                c,
                                "SELECT p.* FROM problems p JOIN contest_problems cp ON"
                                        + " cp.problem_id=p.id WHERE cp.contest_id=? ORDER BY p.id",
                                Problems::item,
                                contest));
    }

    public List<Team> teams() {
        long user = auth.require(Role.Student).id();
        return db.transaction(
                c ->
                        list(
                                c,
                                """
SELECT t.*, m.user_id IS NOT NULL AS joined FROM teams t LEFT JOIN memberships m
ON t.id=m.team_id AND m.user_id=? ORDER BY t.id
""",
                                r ->
                                        new Team(
                                                r.getLong("id"),
                                                r.getString("title"),
                                                r.getString("description"),
                                                r.getBoolean("joined")),
                                user));
    }

    public void join(long team) {
        long user = auth.require(Role.Student).id();
        db.transaction(
                c ->
                        update(
                                c,
                                "MERGE INTO memberships KEY(user_id,team_id) VALUES(?,?)",
                                user,
                                team));
    }

    public Receipt submit(long problem, Language language, String source, Long contest) {
        long user = auth.require(Role.Student).id();
        if (source == null || source.isBlank())
            throw new IllegalArgumentException("Enter some code before submitting.");
        if (language == null) throw new IllegalArgumentException("Choose a programming language.");
        if (source.length() > 100_000)
            throw new IllegalArgumentException("Source limit is 100,000 characters.");
        long submitted = clock.millis();
        var tests =
                db.transaction(
                        c -> {
                            if (list(
                                            c,
                                            "SELECT id FROM problems WHERE id=?",
                                            r -> r.getLong(1),
                                            problem)
                                    .isEmpty())
                                throw new IllegalArgumentException(
                                        "This problem is no longer available.");
                            if (contest != null) {
                                var deadlines =
                                        list(
                                                c,
                                                """
SELECT s.deadline FROM contest_sessions s JOIN contest_problems p ON p.contest_id=s.contest_id
WHERE s.user_id=? AND s.contest_id=? AND p.problem_id=?
""",
                                                r -> r.getLong(1),
                                                user,
                                                contest,
                                                problem);
                                if (deadlines.isEmpty())
                                    throw new IllegalArgumentException(
                                            "Start the contest and choose one of its problems.");
                                if (submitted >= deadlines.get(0))
                                    throw new IllegalArgumentException(
                                            "Time expired. This contest is closed.");
                            }
                            return Problems.samples(c, problem, "judge");
                        });
        Result result;
        try {
            result = judge.evaluate(language, source, tests);
        } catch (RuntimeException ex) {
            result = new Result("Checking failed", "The local checker could not finish.");
        }
        final Result evaluated = result;
        try {
            db.transaction(
                    c ->
                            update(
                                    c,
                                    "INSERT INTO"
                                        + " attempts(user_id,problem_id,contest_id,language,source,verdict,feedback,submitted)"
                                        + " VALUES(?,?,?,?,?,?,?,?)",
                                    user,
                                    problem,
                                    contest,
                                    language.label,
                                    source,
                                    evaluated.verdict(),
                                    evaluated.message(),
                                    submitted));
            return new Receipt(result, true);
        } catch (Database.StorageError e) {
            return new Receipt(result, false);
        }
    }

    public List<Attempt> history(long student) {
        Account viewer = auth.require(Role.Student, Role.Coach);
        if (viewer.role() == Role.Student && viewer.id() != student)
            throw new IllegalStateException("You can view your own progress only.");
        return db.transaction(
                c -> {
                    if (viewer.role() == Role.Coach
                            && list(
                                            c,
                                            "SELECT id FROM accounts WHERE id=? AND role='Student'",
                                            r -> r.getLong(1),
                                            student)
                                    .isEmpty())
                        throw new IllegalArgumentException("Select a current student account.");
                    return list(
                            c,
                            """
SELECT p.id,p.title,p.topic,p.difficulty,a.id AS aid,a.language,a.source,a.verdict,
       a.feedback,a.submitted,t.title AS contest_title FROM attempts a JOIN problems p ON p.id=a.problem_id
LEFT JOIN contests t ON t.id=a.contest_id WHERE a.user_id=? ORDER BY a.submitted DESC,a.id DESC
""",
                            r ->
                                    new Attempt(
                                            r.getLong("aid"),
                                            Problems.item(r),
                                            r.getString("language"),
                                            r.getString("source"),
                                            r.getString("verdict"),
                                            r.getString("feedback"),
                                            r.getLong("submitted"),
                                            r.getString("contest_title")),
                            student);
                });
    }
}
