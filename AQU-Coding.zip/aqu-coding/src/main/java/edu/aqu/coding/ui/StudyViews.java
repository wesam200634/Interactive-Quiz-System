package edu.aqu.coding.ui;

import static edu.aqu.coding.ui.Widgets.*;

import edu.aqu.coding.judge.Language;
import edu.aqu.coding.model.Models.*;

import javafx.concurrent.Task;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

final class StudyViews {
    private final Desktop d;

    StudyViews(Desktop d) {
        this.d = d;
    }

    void bank() {
        catalog(false);
    }

    void catalog(boolean coach) {
        String section = coach ? "Problem library" : "Problems";
        var page =
                d.page(
                        section,
                        coach ? "Problem library" : "Problem bank",
                        coach
                                ? "Create and maintain practice material and its judging tests."
                                : "Find a challenge by title, topic, or difficulty.");
        var title = field("Search by title", "search");
        HBox.setHgrow(title, Priority.ALWAYS);
        var topics = new ArrayList<>(List.of("All topics"));
        topics.addAll(d.problems.topics());
        var topic = choice(topics);
        topic.setId("topic-filter");
        var difficulty = choice(List.of("All levels", "Easy", "Medium", "Hard"));
        difficulty.setId("level-filter");
        var count = label("", "muted");
        var list = itemList();
        Runnable refresh =
                () -> {
                    var rows =
                            d.problems.search(
                                    topic.getSelectionModel().getSelectedIndex() == 0
                                            ? ""
                                            : topic.getValue(),
                                    difficulty.getSelectionModel().getSelectedIndex() == 0
                                            ? ""
                                            : difficulty.getValue(),
                                    title.getText());
                    list.getItems().setAll(rows);
                    count.setText(rows.size() + " " + (rows.size() == 1 ? "problem" : "problems"));
                    if (!rows.isEmpty()) list.getSelectionModel().selectFirst();
                };
        title.textProperty().addListener((a, b, c) -> d.guard(refresh));
        topic.setOnAction(e -> d.guard(refresh));
        difficulty.setOnAction(e -> d.guard(refresh));
        var tools = row(title, topic, difficulty);
        var open =
                openButton(
                        list,
                        coach ? "Edit selected problem" : "Open problem",
                        i -> {
                            if (coach) d.staff.editor(d.problems.open(i.id()));
                            else detail(i.id(), section, null, 0);
                        });
        var actions = row(count, spacer(), open);
        if (coach)
            actions.getChildren()
                    .add(d.action("New problem", "primary", () -> d.staff.editor(null)));
        page.getChildren().addAll(tools, actions, list);
        refresh.run();
    }

    private ListView<Item> itemList() {
        var list = new ListView<Item>();
        list.setId("problem-list");
        list.setFixedCellSize(52);
        list.setPrefHeight(330);
        list.setPlaceholder(label("No matching problems.", "muted"));
        list.setCellFactory(
                v ->
                        new ListCell<>() {
                            @Override
                            protected void updateItem(Item item, boolean empty) {
                                super.updateItem(item, empty);
                                if (empty || item == null) {
                                    setGraphic(null);
                                    setText(null);
                                    return;
                                }
                                var title = label(item.title(), "item-title");
                                var topic = label(item.topic(), "muted");
                                var level =
                                        label(
                                                item.difficulty(),
                                                "level-"
                                                        + item.difficulty()
                                                                .toLowerCase(Locale.ROOT));
                                var line = row(title, spacer(), topic, level);
                                setGraphic(line);
                                setText(null);
                            }
                        });
        return list;
    }

    private Button openButton(ListView<Item> list, String text, Consumer<Item> open) {
        Button b =
                d.action(
                        text,
                        "primary",
                        () -> open.accept(list.getSelectionModel().getSelectedItem()));
        b.disableProperty().bind(list.getSelectionModel().selectedItemProperty().isNull());
        list.setOnMouseClicked(
                e -> {
                    if (e.getClickCount() == 2 && !b.isDisabled()) b.fire();
                });
        list.setOnKeyPressed(
                e -> {
                    if (e.getCode() == javafx.scene.input.KeyCode.ENTER && !b.isDisabled())
                        b.fire();
                });
        return b;
    }

    void saved() {
        var page =
                d.page(
                        "Saved problems",
                        "Saved problems",
                        "Your bookmarked problems, ready to revisit.");
        var items = d.problems.saved();
        if (items.isEmpty()) {
            page.getChildren()
                    .add(
                            card(
                                    label(
                                            "No saved problems yet. Open a problem and choose Save"
                                                    + " problem.",
                                            "muted")));
            return;
        }
        addList(page, items, i -> detail(i.id(), "Saved problems", null, 0));
    }

    private void addList(VBox page, List<Item> items, Consumer<Item> open) {
        var list = itemList();
        list.getItems().setAll(items);
        list.getSelectionModel().selectFirst();
        list.setPrefHeight(Math.min(340, Math.max(60, items.size() * 52 + 3)));
        page.getChildren().addAll(list, openButton(list, "Open problem", open));
    }

    void path() {
        var page =
                d.page(
                        "Learning path",
                        "Learning path",
                        "Start with fundamentals and work toward PCPC-level practice.");
        var items = d.problems.search("", "", "");
        for (String level : List.of("Easy", "Medium", "Hard")) {
            var group = items.stream().filter(i -> i.difficulty().equals(level)).toList();
            if (!group.isEmpty()) {
                page.getChildren()
                        .add(
                                label(
                                        switch (level) {
                                            case "Easy" -> "Foundations";
                                            case "Medium" -> "Core algorithms";
                                            default -> "Competition preparation";
                                        },
                                        "subhead"));
                addList(page, group, i -> detail(i.id(), "Learning path", null, 0));
            }
        }
    }

    void detail(long id, String origin, Contest contest, long deadline) {
        Problem p;
        try {
            p = d.problems.open(id);
        } catch (NoSuchElementException ex) {
            bank();
            d.message(ex.getMessage());
            return;
        }
        var page =
                d.page(
                        origin,
                        p.item().title(),
                        p.item().topic() + "   /   " + p.item().difficulty());
        if (contest != null) {
            var timer = label("", "timer");
            d.clock(deadline, timer);
            page.getChildren()
                    .add(
                            row(
                                    timer,
                                    spacer(),
                                    d.action("Contest problems", "link", () -> contest(contest))));
        }
        boolean bookmarked = d.problems.saved().stream().anyMatch(i -> i.id() == id);
        var save = new Button(bookmarked ? "Remove from saved" : "Save problem");
        save.setOnAction(
                e ->
                        d.guard(
                                () -> {
                                    boolean add = save.getText().equals("Save problem");
                                    d.problems.bookmark(id, add);
                                    save.setText(add ? "Remove from saved" : "Save problem");
                                }));
        var statement =
                card(
                        label("Statement", "subhead"),
                        label(p.statement(), "body-text"),
                        label("Input", "field-name"),
                        label(p.input(), "body-text"),
                        label("Output", "field-name"),
                        label(p.output(), "body-text"));
        var examples = box(8);
        for (Sample s : p.examples())
            examples.getChildren()
                    .add(
                            card(
                                    label("Sample input", "field-name"),
                                    label(s.input().stripTrailing(), "mono"),
                                    label("Sample output", "field-name"),
                                    label(s.output().stripTrailing(), "mono")));
        var hint = new TitledPane("Hint", label(p.hint(), "body-text"));
        hint.setExpanded(false);
        var explanation =
                new TitledPane("Solution explanation", label(p.explanation(), "body-text"));
        explanation.setExpanded(false);
        var language = choice(List.of(Language.values()));
        language.setId("language");
        var code = area("", 10);
        code.setId("source");
        code.setWrapText(false);
        code.getStyleClass().add("editor");
        Runnable prompt =
                () ->
                        code.setPromptText(
                                switch (language.getValue()) {
                                    case JAVA ->
                                            "Write Java 17 code with a Main class and public static"
                                                    + " void main(String[] args).";
                                    case PYTHON ->
                                            "Read from standard input and print the answer using"
                                                    + " Python 3.";
                                    case CPP ->
                                            "Write a C++17 program with an int main() entry point.";
                                });
        prompt.run();
        language.setOnAction(e -> prompt.run());
        var feedback = label("", "feedback");
        feedback.setId("result");
        visible(feedback, false);
        var submit =
                d.action(
                        "Submit",
                        "primary",
                        () -> {
                            if (code.getText().isBlank())
                                throw new IllegalArgumentException(
                                        "Enter some code before submitting.");
                            String source = code.getText();
                            Language lang = language.getValue();
                            Long cid = contest == null ? null : contest.id();
                            feedback.setText("Checking your solution…");
                            visible(feedback, true);
                            d.setBusy(true);
                            page.setDisable(true);
                            Task<Receipt> job =
                                    new Task<>() {
                                        protected Receipt call() {
                                            return d.practice.submit(id, lang, source, cid);
                                        }
                                    };
                            job.setOnSucceeded(
                                    e -> {
                                        d.setBusy(false);
                                        page.setDisable(false);
                                        var r = job.getValue();
                                        feedback.setText(
                                                r.result().verdict()
                                                        + "\n"
                                                        + r.result().message()
                                                        + "\n"
                                                        + (r.saved()
                                                                ? "Saved to your history."
                                                                : "Save failed. This attempt was"
                                                                        + " not recorded. Check the"
                                                                        + " data folder."));
                                    });
                            job.setOnFailed(
                                    e -> {
                                        d.setBusy(false);
                                        page.setDisable(false);
                                        feedback.setText(job.getException().getMessage());
                                    });
                            Thread thread = new Thread(job, "aqu-submission");
                            thread.setDaemon(true);
                            thread.start();
                        });
        submit.setId("submit");
        page.getChildren()
                .addAll(
                        save,
                        statement,
                        examples,
                        hint,
                        explanation,
                        card(
                                row(label("Code editor", "subhead"), spacer(), language),
                                code,
                                row(submit),
                                feedback));
    }

    void contests() {
        var page =
                d.page(
                        "Contests",
                        "Practice contests",
                        "Each round starts its own clock for your account. Reopening a round"
                                + " resumes the same session.");
        for (Contest c : d.practice.contests()) {
            var names =
                    d.practice.contestProblems(c.id()).stream()
                            .map(Item::title)
                            .collect(Collectors.joining("  ·  "));
            page.getChildren()
                    .add(
                            card(
                                    row(
                                            label(c.title(), "subhead"),
                                            spacer(),
                                            label(c.minutes() + " min", "timer")),
                                    label(names, "muted"),
                                    d.action("Start or resume", "primary", () -> contest(c))));
        }
    }

    void contest(Contest c) {
        long deadline = d.practice.start(c);
        var page = d.page("Contests", c.title(), "Choose a problem for this timed round.");
        var timer = label("", "timer");
        d.clock(deadline, timer);
        page.getChildren().add(timer);
        addList(
                page,
                d.practice.contestProblems(c.id()),
                i -> detail(i.id(), "Contests", c, deadline));
    }

    void teams() {
        var page = d.page("Teams", "Training teams", "Join a local practice group.");
        for (Team team : d.practice.teams()) {
            var join =
                    d.action(
                            team.joined() ? "Joined" : "Join team",
                            "secondary",
                            () -> {
                                d.practice.join(team.id());
                                teams();
                            });
            join.setDisable(team.joined());
            page.getChildren()
                    .add(
                            card(
                                    row(label(team.title(), "subhead"), spacer(), join),
                                    label(team.description(), "muted")));
        }
    }

    void progress(long student, boolean coach) {
        var attempts = d.practice.history(student);
        var solved = new LinkedHashMap<Long, Item>();
        Map<String, Integer> topics = new TreeMap<>(), errors = new TreeMap<>();
        for (String topic : d.problems.topics()) topics.put(topic, 0);
        for (Attempt a : attempts) {
            topics.merge(a.problem().topic(), 1, Integer::sum);
            if (a.verdict().equals("Accepted")) solved.put(a.problem().id(), a.problem());
            else errors.merge(a.verdict(), 1, Integer::sum);
        }
        String who =
                coach
                        ? d.auth.directory().stream()
                                .filter(u -> u.id() == student)
                                .map(Account::name)
                                .findFirst()
                                .orElse("Student")
                        : "Your progress";
        var page =
                d.page(
                        coach ? "Student review" : "Progress",
                        who,
                        solved.size()
                                + (solved.size() == 1
                                        ? " problem solved   ·   "
                                        : " problems solved   ·   ")
                                + attempts.size()
                                + (attempts.size() == 1
                                        ? " recorded attempt"
                                        : " recorded attempts"));
        if (coach)
            page.getChildren().add(d.action("Choose another student", "link", d.staff::students));
        page.getChildren().add(label("Solved problems", "subhead"));
        if (solved.isEmpty())
            page.getChildren().add(label("Accepted problems will appear here.", "muted"));
        else if (coach)
            page.getChildren()
                    .add(
                            label(
                                    solved.values().stream()
                                            .map(Item::title)
                                            .collect(Collectors.joining("  ·  ")),
                                    "body-text"));
        else
            addList(
                    page,
                    new ArrayList<>(solved.values()),
                    i -> detail(i.id(), "Progress", null, 0));
        page.getChildren()
                .add(
                        card(
                                label("Attempts by topic", "subhead"),
                                label(counts(topics), "body-text"),
                                label("Recurring results", "field-name"),
                                label(
                                        errors.isEmpty()
                                                ? "No unsuccessful attempts recorded."
                                                : counts(errors),
                                        "muted")));
        page.getChildren().add(label("Submission history", "subhead"));
        if (attempts.isEmpty()) page.getChildren().add(label("No submissions yet.", "muted"));
        var fmt =
                DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm:ss", Locale.ENGLISH)
                        .withZone(ZoneId.systemDefault());
        for (Attempt a : attempts) {
            var meta =
                    fmt.format(Instant.ofEpochMilli(a.time()))
                            + "  ·  "
                            + a.language()
                            + "  ·  "
                            + (a.contest() == null ? "Practice" : a.contest());
            var source = area(a.source(), 5);
            source.setEditable(false);
            source.setWrapText(false);
            source.getStyleClass().add("editor");
            var content = box(8, label(a.feedback(), "body-text"), source);
            if (!coach)
                content.getChildren()
                        .add(
                                d.action(
                                        "Reopen problem",
                                        "link",
                                        () -> detail(a.problem().id(), "Progress", null, 0)));
            var reveal = new TitledPane("Review submission", content);
            reveal.setExpanded(false);
            page.getChildren()
                    .add(
                            card(
                                    row(
                                            label(a.problem().title(), "item-title"),
                                            spacer(),
                                            label(a.verdict(), "field-name")),
                                    label(meta, "muted"),
                                    reveal));
        }
    }

    private static String counts(Map<String, Integer> map) {
        return map.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .map(e -> e.getKey() + " (" + e.getValue() + ")")
                .collect(Collectors.joining("   ·   "));
    }
}
