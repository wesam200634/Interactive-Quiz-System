package edu.aqu.coding.service;

import static edu.aqu.coding.data.Database.*;

import edu.aqu.coding.data.Database;
import edu.aqu.coding.model.Models.*;

import java.security.*;
import java.sql.*;
import java.util.*;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class Accounts {
    private final Database db;
    private volatile Account current;
    private static final SecureRandom RANDOM = new SecureRandom();

    public Accounts(Database db) {
        this.db = db;
    }

    public boolean needsSetup() {
        return db.transaction(
                c -> list(c, "SELECT id FROM setup_state", r -> r.getInt(1)).isEmpty());
    }

    public void setup(String name, String number, String password) {
        create(name, number, password, true);
    }

    public void register(String name, String number, String password) {
        create(name, number, password, false);
    }

    private void create(String name, String number, String password, boolean first) {
        if (name == null || name.isBlank() || name.strip().length() > 100)
            throw new IllegalArgumentException("Enter a name of 1–100 characters.");
        if (number == null || !number.strip().matches("[0-9]{1,50}"))
            throw new IllegalArgumentException("Enter your university number using digits.");
        if (password == null
                || password.isBlank()
                || password.length() < 8
                || password.length() > 256)
            throw new IllegalArgumentException("Use a password of 8–256 characters.");
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        byte[] key = hash(password, salt);
        db.transaction(
                c -> {
                    boolean initialized =
                            !list(c, "SELECT id FROM setup_state", r -> r.getInt(1)).isEmpty();
                    if (first == initialized)
                        throw new IllegalStateException(
                                first
                                        ? "Administrator setup is already complete."
                                        : "Set up the local administrator first.");
                    long id;
                    try {
                        id =
                                insert(
                                        c,
                                        "INSERT INTO accounts(name,number,salt,digest,role)"
                                                + " VALUES(?,?,?,?,?)",
                                        name.strip(),
                                        number.strip(),
                                        salt,
                                        key,
                                        first ? "Administrator" : "Student");
                    } catch (SQLException e) {
                        if ("23505".equals(e.getSQLState()))
                            throw new IllegalArgumentException(
                                    "That university number is already registered.");
                        throw e;
                    }
                    if (first) update(c, "INSERT INTO setup_state VALUES(1,?)", id);
                    return null;
                });
    }

    private static byte[] hash(String password, byte[] salt) {
        var spec = new PBEKeySpec(password.toCharArray(), salt, 210_000, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec)
                    .getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Password verification is unavailable.", e);
        } finally {
            spec.clearPassword();
        }
    }

    private static Account account(ResultSet r) throws SQLException {
        return new Account(
                r.getLong("id"),
                r.getString("number"),
                r.getString("name"),
                Role.valueOf(r.getString("role")));
    }

    public Account login(String number, String password) {
        current = null;
        current =
                db.transaction(
                        c -> {
                            var matches =
                                    list(
                                            c,
                                            "SELECT * FROM accounts WHERE number=?",
                                            r -> {
                                                if (!MessageDigest.isEqual(
                                                        r.getBytes("digest"),
                                                        hash(password, r.getBytes("salt"))))
                                                    return null;
                                                return account(r);
                                            },
                                            number.strip());
                            if (matches.isEmpty() || matches.get(0) == null)
                                throw new IllegalArgumentException(
                                        "University number or password is incorrect.");
                            return matches.get(0);
                        });
        return current;
    }

    public void logout() {
        current = null;
    }

    public Account require(Role... roles) {
        Account user = current;
        if (user == null || (roles.length > 0 && !Arrays.asList(roles).contains(user.role())))
            throw new IllegalStateException(
                    "Sign in with an authorized account to use this feature.");
        return user;
    }

    public List<Account> directory() {
        Role role = require(Role.Coach, Role.Administrator).role();
        String sql =
                "SELECT id,number,name,role FROM accounts"
                        + (role == Role.Coach ? " WHERE role='Student'" : "")
                        + " ORDER BY name,number";
        return db.transaction(c -> list(c, sql, Accounts::account));
    }

    public void changeRole(long id, Role role) {
        require(Role.Administrator);
        Objects.requireNonNull(role);
        db.transaction(
                c -> {
                    var admins =
                            list(
                                    c,
                                    "SELECT id FROM accounts WHERE role='Administrator' ORDER BY id"
                                            + " FOR UPDATE",
                                    r -> r.getLong(1));
                    if (role != Role.Administrator && admins.equals(List.of(id)))
                        throw new IllegalArgumentException(
                                "Keep at least one administrator account.");
                    if (update(c, "UPDATE accounts SET role=? WHERE id=?", role.name(), id) != 1)
                        throw new IllegalArgumentException("Account no longer exists.");
                    return null;
                });
    }
}
