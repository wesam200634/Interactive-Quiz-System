package edu.aqu.coding.model;

import java.util.List;

public final class Models {
    private Models() {}

    public enum Role {
        Student,
        Coach,
        Administrator
    }

    public record Account(long id, String number, String name, Role role) {
        public String toString() {
            return name + " · " + number + " · " + role;
        }
    }

    public record Item(long id, String title, String topic, String difficulty) {
        public String toString() {
            return title + "   ·   " + topic + "   ·   " + difficulty;
        }
    }

    public record Sample(String input, String output) {}

    public record Problem(
            Item item,
            String statement,
            String input,
            String output,
            String hint,
            String explanation,
            List<Sample> examples,
            List<Sample> tests) {}

    public record Contest(long id, String title, int minutes) {
        public String toString() {
            return title + "   ·   " + minutes + " min";
        }
    }

    public record Team(long id, String title, String description, boolean joined) {}

    public record Attempt(
            long id,
            Item problem,
            String language,
            String source,
            String verdict,
            String feedback,
            long time,
            String contest) {}

    public record Result(String verdict, String message) {}

    public record Receipt(Result result, boolean saved) {}
}
