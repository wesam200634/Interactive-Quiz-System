package edu.aqu.coding.ui;

import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;

final class Widgets {
    private Widgets() {}

    static Label label(String text, String style) {
        var l = new Label(text);
        l.setWrapText(true);
        l.getStyleClass().add(style);
        return l;
    }

    static VBox box(double space, Node... children) {
        return new VBox(space, children);
    }

    static VBox card(Node... children) {
        var b = box(10, children);
        b.getStyleClass().add("card");
        return b;
    }

    static HBox row(Node... children) {
        var h = new HBox(10, children);
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    static Region spacer() {
        var r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }

    static Button button(String text, String style, Runnable action) {
        var b = new Button(text);
        b.getStyleClass().add(style);
        b.setOnAction(e -> action.run());
        return b;
    }

    static TextField field(String prompt, String id) {
        var f = new TextField();
        f.setPromptText(prompt);
        f.setId(id);
        return f;
    }

    static TextArea area(String text, int rows) {
        var a = new TextArea(text);
        a.setWrapText(true);
        a.setPrefRowCount(rows);
        return a;
    }

    static <T> ComboBox<T> choice(List<T> choices) {
        var c = new ComboBox<T>();
        c.getItems().setAll(choices);
        if (!choices.isEmpty()) c.getSelectionModel().selectFirst();
        c.setMaxWidth(Double.MAX_VALUE);
        return c;
    }

    static VBox fieldGroup(String title, Control field) {
        Label l = label(title, "field-name");
        l.setLabelFor(field);
        return box(5, l, field);
    }

    static ScrollPane scroll(Node content) {
        var s = new ScrollPane(content);
        s.setFitToWidth(true);
        s.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        return s;
    }

    static void visible(Node node, boolean show) {
        node.setVisible(show);
        node.setManaged(show);
    }
}
