package edu.aqu.coding;

import edu.aqu.coding.data.Database;
import edu.aqu.coding.judge.DockerJudge;
import edu.aqu.coding.service.*;
import edu.aqu.coding.ui.Desktop;

import javafx.application.Application;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.nio.file.Path;
import java.time.Clock;

public final class Main extends Application {
    public void start(Stage stage) {
        try {
            String location =
                    System.getProperty(
                            "aqu.data",
                            Path.of(System.getProperty("user.home"), ".aqu-coding", "practice")
                                    .toString());
            var db = new Database(Path.of(location));
            var auth = new Accounts(db);
            new Desktop(
                            stage,
                            auth,
                            new Problems(db, auth),
                            new Practice(db, auth, new DockerJudge(), Clock.systemUTC()))
                    .show();
        } catch (RuntimeException e) {
            new Alert(
                            Alert.AlertType.ERROR,
                            "AQU Coding could not open its data folder. " + e.getMessage())
                    .showAndWait();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
