package edu.aqu.coding.service;

import static edu.aqu.coding.data.Database.*;

import edu.aqu.coding.data.Database;
import edu.aqu.coding.model.Models.*;

import java.sql.*;
import java.util.*;

public final class Problems {
    private final Database db;
    private final Accounts auth;

    public Problems(Database db, Accounts auth) {
        this.db = db;
        this.auth = auth;
    }

    static Item item(ResultSet r) throws SQLException {
        return new Item(
                r.getLong("id"),
                r.getString("title"),
                r.getString("topic"),
                r.getString("difficulty"));
    }

    private static final String ORDER =
            " ORDER BY CASE difficulty WHEN 'Easy' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END,p.id";

    public List<Item> search(String topic, String difficulty, String title) {
        auth.require(Role.Student, Role.Coach);
        return db.transaction(
                c ->
                        list(
                                c,
                                """
SELECT p.* FROM problems p WHERE (?='' OR topic=?) AND (?='' OR difficulty=?)
AND LOCATE(LOWER(?),LOWER(title))>0
"""
                                        + ORDER,
                                Problems::item,
                                topic,
                                topic,
                                difficulty,
                                difficulty,
                                title.strip()));
    }

    public List<String> topics() {
        auth.require(Role.Student, Role.Coach);
        return db.transaction(
                c ->
                        list(
                                c,
                                "SELECT DISTINCT topic FROM problems ORDER BY topic",
                                r -> r.getString(1)));
    }

    public List<Item> saved() {
        long user = auth.require(Role.Student).id();
        return db.transaction(
                c ->
                        list(
                                c,
                                "SELECT p.* FROM problems p JOIN saved s ON s.problem_id=p.id WHERE"
                                        + " s.user_id=?"
                                        + ORDER,
                                Problems::item,
                                user));
    }

    public void bookmark(long problem, boolean save) {
        long user = auth.require(Role.Student).id();
        db.transaction(
                c ->
                        update(
                                c,
                                save
                                        ? "MERGE INTO saved KEY(user_id,problem_id) VALUES(?,?)"
                                        : "DELETE FROM saved WHERE user_id=? AND problem_id=?",
                                user,
                                problem));
    }

    public Problem open(long id) {
        boolean coach = auth.require(Role.Coach, Role.Student).role() == Role.Coach;
        return db.transaction(
                c -> {
                    var rows =
                            list(
                                    c,
                                    "SELECT * FROM problems WHERE id=?",
                                    r ->
                                            new Problem(
                                                    item(r),
                                                    r.getString("statement"),
                                                    r.getString("inputs"),
                                                    r.getString("outputs"),
                                                    r.getString("hint"),
                                                    r.getString("explanation"),
                                                    samples(c, id, "example"),
                                                    coach ? samples(c, id, "judge") : List.of()),
                                    id);
                    if (rows.isEmpty())
                        throw new NoSuchElementException("This problem is no longer available.");
                    return rows.get(0);
                });
    }

    static List<Sample> samples(Connection c, long id, String kind) throws SQLException {
        return list(
                c,
                "SELECT stdin,expected FROM cases WHERE problem_id=? AND kind=? ORDER BY position",
                r -> new Sample(r.getString(1), r.getString(2)),
                id,
                kind);
    }

    public long publish(Problem p) {
        auth.require(Role.Coach);
        var i = p.item();
        String[] values = {
            i.title(),
            i.topic(),
            i.difficulty(),
            p.statement(),
            p.input(),
            p.output(),
            p.hint(),
            p.explanation()
        };
        String[] fields = {
            "title",
            "topic",
            "difficulty",
            "statement",
            "input rules",
            "output rules",
            "hint",
            "explanation"
        };
        for (int n = 0; n < fields.length; n++)
            if (values[n] == null || values[n].isBlank())
                throw new IllegalArgumentException("Enter the " + fields[n] + ".");
        if (i.title().strip().length() > 160 || i.topic().strip().length() > 80)
            throw new IllegalArgumentException("Title limit is 160 characters. Topic limit is 80.");
        if (!List.of("Easy", "Medium", "Hard").contains(i.difficulty()))
            throw new IllegalArgumentException("Choose a valid difficulty.");
        validateCases("example", p.examples());
        validateCases("judging test", p.tests());
        return db.transaction(
                c -> {
                    Object[] args = {
                        i.title().strip(),
                        i.topic().strip(),
                        i.difficulty(),
                        p.statement(),
                        p.input(),
                        p.output(),
                        p.hint(),
                        p.explanation()
                    };
                    long id = i.id();
                    if (id == 0)
                        id =
                                insert(
                                        c,
                                        "INSERT INTO"
                                            + " problems(title,topic,difficulty,statement,inputs,outputs,hint,explanation)"
                                            + " VALUES(?,?,?,?,?,?,?,?)",
                                        args);
                    else {
                        var data = Arrays.copyOf(args, 9);
                        data[8] = id;
                        if (update(
                                        c,
                                        "UPDATE problems SET"
                                            + " title=?,topic=?,difficulty=?,statement=?,inputs=?,outputs=?,hint=?,explanation=?"
                                            + " WHERE id=?",
                                        data)
                                != 1)
                            throw new NoSuchElementException(
                                    "This problem is no longer available.");
                        update(c, "DELETE FROM cases WHERE problem_id=?", id);
                    }
                    storeCases(c, id, "example", p.examples());
                    storeCases(c, id, "judge", p.tests());
                    return id;
                });
    }

    private static void validateCases(String type, List<Sample> pairs) {
        if (pairs == null || pairs.isEmpty() || pairs.size() > 32)
            throw new IllegalArgumentException("Provide between 1 and 32 " + type + " pairs.");
        for (Sample s : pairs) {
            if (s.input() == null
                    || s.output() == null
                    || (s.input().isBlank() && s.output().isBlank()))
                throw new IllegalArgumentException("Complete the " + type + " pair.");
            if (s.input().length() > 100_000
                    || s.output().getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 65536)
                throw new IllegalArgumentException(
                        "The " + type + " exceeds the input or output limit.");
        }
    }

    private static void storeCases(Connection c, long id, String kind, List<Sample> pairs)
            throws SQLException {
        for (int n = 0; n < pairs.size(); n++) {
            Sample s = pairs.get(n);
            update(c, "INSERT INTO cases VALUES(?,?,?,?,?)", id, kind, n, s.input(), s.output());
        }
    }
}
