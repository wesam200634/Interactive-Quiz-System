package edu.aqu.coding.judge;

public enum Language {
    JAVA(
            "Java",
            "amazoncorretto:17-alpine",
            "Main.java",
            "javac",
            "javac -J-Xmx160m -proc:none Main.java",
            "java -XX:-UseContainerSupport -Xmx96m -XX:ActiveProcessorCount=1 -cp . Main"),
    CPP("C++", "aqu-cpp:1", "main.cpp", "g++", "g++ -std=c++17 -O1 main.cpp -o main", "./main"),
    PYTHON(
            "Python",
            "python:3.12-alpine",
            "main.py",
            "python3",
            "python3 -m py_compile main.py",
            "python3 -I main.py");
    public final String label, image, filename, tool, compile, run;

    Language(String label, String image, String filename, String tool, String compile, String run) {
        this.label = label;
        this.image = image;
        this.filename = filename;
        this.tool = tool;
        this.compile = compile;
        this.run = run;
    }

    @Override
    public String toString() {
        return label;
    }
}
