package edu.aqu.coding.judge;

import edu.aqu.coding.model.Models.*;

import java.util.List;

@FunctionalInterface
public interface Judge {
    Result evaluate(Language language, String source, List<Sample> tests);
}
