package edu.aqu.coding.ui;

import static edu.aqu.coding.ui.Widgets.*;

import edu.aqu.coding.model.Models.*;

import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.*;

final class StaffViews {
    private final Desktop d;

    StaffViews(Desktop d) {
        this.d = d;
    }

    void library() {
        d.study.catalog(true);
    }

    void students() {
        var page =
                d.page(
                        "Student review",
                        "Student review",
                        "Inspect a student’s solved problems, attempts, and recurring results.");
        var users = d.auth.directory();
        if (users.isEmpty()) {
            page.getChildren().add(label("No student accounts yet.", "muted"));
            return;
        }
        var select = choice(users);
        select.setId("students");
        page.getChildren()
                .add(
                        card(
                                fieldGroup("Student", select),
                                d.action(
                                        "View progress",
                                        "primary",
                                        () -> d.study.progress(select.getValue().id(), true))));
    }

    void accounts() {
        var page =
                d.page(
                        "Accounts",
                        "Account roles",
                        "Select a local account to manage its access. Changes take effect at its"
                                + " next sign-in.");
        var users = d.auth.directory();
        var select = choice(users);
        select.setId("accounts");
        var role = choice(List.of(Role.values()));
        role.setId("role");
        role.setValue(select.getValue().role());
        select.setOnAction(e -> role.setValue(select.getValue().role()));
        page.getChildren()
                .add(
                        card(
                                fieldGroup("Account", select),
                                fieldGroup("Access role", role),
                                d.action(
                                        "Save role",
                                        "primary",
                                        () -> {
                                            d.auth.changeRole(
                                                    select.getValue().id(), role.getValue());
                                            accounts();
                                            d.message(
                                                    "Role saved. The account will use it at its"
                                                            + " next sign-in.");
                                        })));
    }

    void editor(Problem p) {
        var page =
                d.page(
                        "Problem library",
                        p == null ? "New problem" : "Edit problem",
                        p == null
                                ? "Prepare the statement, examples, and tests for publication."
                                : p.item().title());
        var title = field("Problem title", "problem-title");
        var topic = field("Topic", "problem-topic");
        var difficulty = choice(List.of("Easy", "Medium", "Hard"));
        var statement = area("", 4);
        statement.setId("statement");
        var input = area("", 2);
        var output = area("", 2);
        var hint = area("", 2);
        var explanation = area("", 3);
        input.setId("input-rules");
        output.setId("output-rules");
        hint.setId("hint");
        explanation.setId("explanation");
        if (p != null) {
            title.setText(p.item().title());
            topic.setText(p.item().topic());
            difficulty.setValue(p.item().difficulty());
            statement.setText(p.statement());
            input.setText(p.input());
            output.setText(p.output());
            hint.setText(p.hint());
            explanation.setText(p.explanation());
        }
        var examples = new Pairs("Example", p == null ? List.of() : p.examples());
        var tests = new Pairs("Judging test", p == null ? List.of() : p.tests());
        var topicGroup = fieldGroup("Topic", topic);
        HBox.setHgrow(topicGroup, Priority.ALWAYS);
        page.getChildren()
                .addAll(
                        card(
                                fieldGroup("Title", title),
                                row(topicGroup, fieldGroup("Difficulty", difficulty)),
                                fieldGroup("Statement", statement),
                                fieldGroup("Input rules", input),
                                fieldGroup("Output rules", output)),
                        examples.root,
                        tests.root,
                        card(
                                fieldGroup("Hint", hint),
                                fieldGroup("Solution explanation", explanation)),
                        row(
                                d.action(
                                        "Save problem",
                                        "primary",
                                        () -> {
                                            var item =
                                                    new Item(
                                                            p == null ? 0 : p.item().id(),
                                                            title.getText(),
                                                            topic.getText(),
                                                            difficulty.getValue());
                                            d.problems.publish(
                                                    new Problem(
                                                            item,
                                                            statement.getText(),
                                                            input.getText(),
                                                            output.getText(),
                                                            hint.getText(),
                                                            explanation.getText(),
                                                            examples.values(),
                                                            tests.values()));
                                            library();
                                            d.message("Problem saved.");
                                        }),
                                d.action("Back to library", "link", this::library)));
    }

    private final class Pairs {
        final VBox root, rows = box(10);
        final String kind;
        final Map<VBox, List<TextArea>> fields = new LinkedHashMap<>();

        Pairs(String kind, List<Sample> initial) {
            this.kind = kind;
            root =
                    card(
                            label(
                                    kind.equals("Example")
                                            ? "Public examples"
                                            : "Hidden judging tests",
                                    "subhead"),
                            rows,
                            d.action(
                                    "Add " + kind.toLowerCase(Locale.ROOT),
                                    "secondary",
                                    () -> add(new Sample("", ""))));
            if (initial.isEmpty()) add(new Sample("", ""));
            else initial.forEach(this::add);
        }

        void add(Sample s) {
            var input = area(s.input(), 3);
            var output = area(s.output(), 3);
            input.setId(kind.equals("Example") ? "example-in" : "test-in");
            output.setId(kind.equals("Example") ? "example-out" : "test-out");
            var left = fieldGroup("Input", input);
            var right = fieldGroup("Expected output", output);
            HBox.setHgrow(left, Priority.ALWAYS);
            HBox.setHgrow(right, Priority.ALWAYS);
            var entry = box(4, row(left, right));
            fields.put(entry, List.of(input, output));
            rows.getChildren().add(entry);
            entry.getChildren()
                    .add(
                            d.action(
                                    "Remove pair",
                                    "link",
                                    () -> {
                                        rows.getChildren().remove(entry);
                                        fields.remove(entry);
                                    }));
        }

        List<Sample> values() {
            return fields.values().stream()
                    .map(v -> new Sample(v.get(0).getText(), v.get(1).getText()))
                    .toList();
        }
    }
}
