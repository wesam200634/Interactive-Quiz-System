package edu.aqu.coding.data;

import org.h2.tools.RunScript;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public final class Database {
    private final String url;

    public Database(Path file) {
        try {
            Path path = file.toAbsolutePath().normalize();
            Files.createDirectories(path.getParent());
            if (path.toString().contains(";"))
                throw new IllegalArgumentException("Choose a database path without a semicolon.");
            url = "jdbc:h2:file:" + path + ";DB_CLOSE_ON_EXIT=FALSE";
            transaction(
                    c -> {
                        script(c, "schema.sql");
                        if (list(c, "SELECT version FROM app_meta", r -> r.getInt(1)).isEmpty()) {
                            script(c, "seed.sql");
                            update(c, "INSERT INTO app_meta VALUES(1)");
                        }
                        return null;
                    });
        } catch (IOException e) {
            throw new IllegalStateException("Cannot create the database directory.", e);
        }
    }

    private static void script(Connection c, String name) throws SQLException {
        try (var in = Database.class.getResourceAsStream("/" + name);
                var reader =
                        new InputStreamReader(Objects.requireNonNull(in), StandardCharsets.UTF_8)) {
            RunScript.execute(c, reader);
        } catch (IOException e) {
            throw new SQLException("Cannot read " + name, e);
        }
    }

    public interface Work<T> {
        T run(Connection c) throws SQLException;
    }

    public interface Row<T> {
        T read(ResultSet r) throws SQLException;
    }

    public <T> T transaction(Work<T> work) {
        try (Connection c = DriverManager.getConnection(url, "sa", "")) {
            c.setAutoCommit(false);
            try {
                T result = work.run(c);
                c.commit();
                return result;
            } catch (SQLException | RuntimeException ex) {
                c.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            throw new StorageError(e);
        }
    }

    public static final class StorageError extends RuntimeException {
        public StorageError(SQLException cause) {
            super(
                    "Local database operation failed. Check the data folder and available disk"
                            + " space.",
                    cause);
        }
    }

    public static void bind(PreparedStatement s, Object... args) throws SQLException {
        for (int i = 0; i < args.length; i++) s.setObject(i + 1, args[i]);
    }

    public static int update(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement s = c.prepareStatement(sql)) {
            bind(s, args);
            return s.executeUpdate();
        }
    }

    public static long insert(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement s = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(s, args);
            s.executeUpdate();
            try (ResultSet r = s.getGeneratedKeys()) {
                if (!r.next()) throw new SQLException("Missing new record identifier");
                return r.getLong(1);
            }
        }
    }

    public static <T> List<T> list(Connection c, String sql, Row<T> row, Object... args)
            throws SQLException {
        try (PreparedStatement s = c.prepareStatement(sql)) {
            bind(s, args);
            try (ResultSet r = s.executeQuery()) {
                List<T> rows = new ArrayList<>();
                while (r.next()) rows.add(row.read(r));
                return rows;
            }
        }
    }
}
