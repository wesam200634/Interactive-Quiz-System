package edu.aqu.coding.judge;

import edu.aqu.coding.model.Models.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Only source and one test input cross the container boundary. Expected answers stay in Java. */
public final class DockerJudge implements Judge {
    private static final int OUTPUT_LIMIT = 65536;
    private static final int DEADLINE_SECONDS = 25;
    private static final String FAILED = "Checking failed";

    @Override
    public Result evaluate(Language language, String source, List<Sample> tests) {
        if (tests.isEmpty())
            return new Result(
                    FAILED, "This problem has no judging tests. Ask a coach to review it.");
        for (int i = 0; i < tests.size(); i++) {
            Sample test = tests.get(i);
            Result result = runCase(language, source, test, i + 1);
            if (result != null) return result;
        }
        return new Result("Accepted", "Passed all " + tests.size() + " required tests.");
    }

    private Result runCase(Language lang, String source, Sample test, int index) {
        String name = "aqu-check-" + UUID.randomUUID();
        var args =
                new ArrayList<>(
                        List.of(
                                "docker",
                                "run",
                                "--rm",
                                "-i",
                                "--pull=never",
                                "--name",
                                name,
                                "--network",
                                "none",
                                "--read-only",
                                "--user",
                                "65534:65534",
                                "--cap-drop",
                                "ALL",
                                "--security-opt",
                                "no-new-privileges",
                                "--pids-limit",
                                "80",
                                "--cpus",
                                "1",
                                "--memory",
                                "384m",
                                "--memory-swap",
                                "384m",
                                "--ulimit",
                                "nofile=128:128",
                                "--log-driver",
                                "none",
                                "--tmpfs",
                                "/work:rw,exec,nosuid,nodev,size=48m,mode=1777",
                                "--tmpfs",
                                "/tmp:rw,noexec,nosuid,nodev,size=16m,mode=1777",
                                "-w",
                                "/work"));
        for (String key :
                List.of("HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "ALL_PROXY", "FTP_PROXY")) {
            args.addAll(List.of("-e", key + "=", "-e", key.toLowerCase(Locale.ROOT) + "="));
        }
        String command =
                "command -v "
                        + lang.tool
                        + " >/dev/null || exit 24\n"
                        + "IFS= read -r src && printf '%s' \"$src\" | base64 -d > "
                        + lang.filename
                        + " || exit 24\n"
                        + "cat > case.in || exit 24\n"
                        + "timeout -s KILL 12 "
                        + lang.compile
                        + " >&2 </dev/null\n"
                        + "case $? in 0) ;; 137|124) exit 23;; *) exit 21;; esac\n"
                        + "timeout -s KILL 3 "
                        + lang.run
                        + " < case.in\n"
                        + "case $? in 0) exit 0;; 137|124) exit 23;; *) exit 22;; esac";
        args.addAll(List.of("--entrypoint", "/bin/sh", lang.image, "-c", command));
        Process process;
        try {
            process = new ProcessBuilder(args).start();
        } catch (IOException e) {
            return new Result(
                    FAILED,
                    "Docker could not start. Install Docker and prepare the local judge images.");
        }
        var threads =
                Executors.newFixedThreadPool(
                        3,
                        r -> {
                            var t = new Thread(r, "aqu-judge-io");
                            t.setDaemon(true);
                            return t;
                        });
        var overflow = new AtomicBoolean();
        var stdout = threads.submit(() -> collect(process.getInputStream(), process, overflow));
        var stderr = threads.submit(() -> collect(process.getErrorStream(), process, overflow));
        var input =
                threads.submit(
                        () -> {
                            try (var out = process.getOutputStream()) {
                                out.write(
                                        Base64.getEncoder()
                                                .encode(source.getBytes(StandardCharsets.UTF_8)));
                                out.write('\n');
                                out.write(test.input().getBytes(StandardCharsets.UTF_8));
                            }
                            return null;
                        });
        boolean cleanup = false;
        try {
            if (!process.waitFor(DEADLINE_SECONDS, TimeUnit.SECONDS)) {
                cleanup = true;
                return new Result(
                        FAILED, "The local checker exceeded its time limit on test " + index + ".");
            }
            if (overflow.get()) {
                cleanup = true;
                return new Result(FAILED, "Output limit exceeded on test " + index + ".");
            }
            String out = stdout.get(2, TimeUnit.SECONDS), err = stderr.get(2, TimeUnit.SECONDS);
            String detail = err.strip();
            if (detail.length() > 1000) detail = detail.substring(0, 1000);
            return switch (process.exitValue()) {
                case 0 -> {
                    input.get(2, TimeUnit.SECONDS);
                    yield normalize(out).equals(normalize(test.output()))
                            ? null
                            : new Result(
                                    "Wrong Answer",
                                    "Output differed on required test "
                                            + index
                                            + ". Check formatting and edge cases.");
                }
                case 21 ->
                        new Result(
                                "Compilation Error",
                                detail.isBlank() ? "The compiler rejected the source." : detail);
                case 22 ->
                        new Result(
                                "Runtime Error",
                                "The program stopped on test " + index + ".\n" + detail);
                case 23, 137 ->
                        new Result(FAILED, "Time or memory limit reached on test " + index + ".");
                default ->
                        new Result(
                                FAILED,
                                "The local judge is unavailable. Start Docker and prepare the "
                                        + lang
                                        + " image.\n"
                                        + detail);
            };
        } catch (InterruptedException e) {
            cleanup = true;
            Thread.currentThread().interrupt();
            return new Result(FAILED, "Checking was interrupted.");
        } catch (ExecutionException | TimeoutException e) {
            cleanup = true;
            return new Result(FAILED, "Could not transfer input or read the finished result.");
        } finally {
            if (cleanup || process.isAlive()) {
                process.destroyForcibly();
                try {
                    var rm =
                            new ProcessBuilder("docker", "rm", "-f", name)
                                    .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                                    .redirectError(ProcessBuilder.Redirect.DISCARD)
                                    .start();
                    if (!rm.waitFor(5, TimeUnit.SECONDS)) rm.destroyForcibly();
                } catch (IOException ignored) {
                    // The daemon itself may be unavailable.
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            threads.shutdownNow();
        }
    }

    private static String collect(InputStream in, Process process, AtomicBoolean overflow)
            throws IOException {
        try (in;
                var bytes = new ByteArrayOutputStream()) {
            byte[] block = new byte[4096];
            int read;
            while ((read = in.read(block)) != -1) {
                if (bytes.size() + read > OUTPUT_LIMIT) {
                    overflow.set(true);
                    process.destroyForcibly();
                    break;
                }
                bytes.write(block, 0, read);
            }
            return bytes.toString(StandardCharsets.UTF_8);
        }
    }

    private static String normalize(String value) {
        return value.replace("\r\n", "\n").replace('\r', '\n').stripTrailing();
    }
}
