package edu.aqu.coding;

import static org.junit.jupiter.api.Assertions.*;

import edu.aqu.coding.data.Database;
import edu.aqu.coding.judge.*;
import edu.aqu.coding.model.Models.*;
import edu.aqu.coding.service.*;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

class SeedContentTest {
    @TempDir Path temp;

    @TestFactory
    Stream<DynamicTest> referenceSolutionsPassExamplesAndHiddenCases() {
        var db = new Database(temp.resolve("seed"));
        var auth = new Accounts(db);
        var problems = new Problems(db, auth);
        auth.setup("Admin", "1", "testing123");
        auth.register("Coach", "2", "testing123");
        auth.login("1", "testing123");
        long id =
                auth.directory().stream()
                        .filter(a -> a.number().equals("2"))
                        .findFirst()
                        .orElseThrow()
                        .id();
        auth.changeRole(id, Role.Coach);
        auth.login("2", "testing123");
        return problems.search("", "", "").stream()
                .map(
                        item ->
                                DynamicTest.dynamicTest(
                                        item.title(),
                                        () -> {
                                            var content = problems.open(item.id());
                                            var cases = new LinkedHashSet<>(content.examples());
                                            cases.addAll(content.tests());
                                            String code =
                                                    Files.readString(
                                                            Path.of(
                                                                    "src/test/resources/solutions",
                                                                    Long.toString(item.id()),
                                                                    "Main.java"));
                                            var result =
                                                    new DockerJudge()
                                                            .evaluate(
                                                                    Language.JAVA,
                                                                    code,
                                                                    List.copyOf(cases));
                                            assertEquals(
                                                    "Accepted", result.verdict(), result.message());
                                        }));
    }
}
