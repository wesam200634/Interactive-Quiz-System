package edu.aqu.coding;

import static org.junit.jupiter.api.Assertions.*;

import edu.aqu.coding.judge.*;
import edu.aqu.coding.model.Models.*;

import org.junit.jupiter.api.Test;

import java.util.*;

class JudgeTest {
    final DockerJudge judge = new DockerJudge();
    final List<Sample> tests = List.of(new Sample("2 4\n", "6\n"), new Sample("10 3\n", "13\n"));

    void expect(String verdict, Language lang, String code) {
        var result = judge.evaluate(lang, code, tests);
        assertEquals(verdict, result.verdict(), result.message());
    }

    @Test
    void javaCompilesAndPassesEveryTest() {
        expect(
                "Accepted",
                Language.JAVA,
                "import java.util.*; class Main {public static void main(String[] args){Scanner"
                    + " s=new Scanner(System.in);System.out.println(s.nextInt()+s.nextInt());}}");
    }

    @Test
    void cppCompilesAndPassesEveryTest() {
        expect(
                "Accepted",
                Language.CPP,
                "#include <iostream>\nint main(){int a,b;std::cin>>a>>b;std::cout<<a+b;}");
    }

    @Test
    void pythonRunsAndPassesEveryTest() {
        expect("Accepted", Language.PYTHON, "print(sum(map(int,input().split())))");
    }

    @Test
    void passingSampleAloneIsInsufficient() {
        expect("Wrong Answer", Language.PYTHON, "print(6)");
    }

    @Test
    void javaCompilerError() {
        expect("Compilation Error", Language.JAVA, "class Main { broken }");
    }

    @Test
    void cppCompilerError() {
        expect("Compilation Error", Language.CPP, "int main( {");
    }

    @Test
    void runtimeError() {
        expect("Runtime Error", Language.PYTHON, "raise ValueError('invalid')");
    }

    @Test
    void boundedExecution() {
        expect("Checking failed", Language.PYTHON, "while True: pass");
    }

    @Test
    void boundedOutput() {
        expect("Checking failed", Language.PYTHON, "print('x' * 150000)");
    }

    @Test
    void correctProgramCanIgnoreUnusedInput() {
        var sample = new Sample("z".repeat(95_000), "ok");
        var result = judge.evaluate(Language.PYTHON, "print('ok')", List.of(sample));
        assertEquals("Accepted", result.verdict(), result.message());
    }

    @Test
    void emptyTestsCannotPass() {
        assertEquals("Checking failed", judge.evaluate(Language.JAVA, "", List.of()).verdict());
    }
}
