package edu.aqu.coding;

import static edu.aqu.coding.data.Database.*;

import static org.junit.jupiter.api.Assertions.*;

import edu.aqu.coding.data.*;
import edu.aqu.coding.judge.*;
import edu.aqu.coding.model.Models.*;
import edu.aqu.coding.service.*;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

class WorkflowTest {
    @TempDir Path temp;
    Database db;
    Accounts auth;
    Problems bank;
    Practice study;
    long admin, student, coach;
    final AtomicInteger calls = new AtomicInteger();
    final String password = "course-password";
    Clock clock = Clock.fixed(Instant.parse("2026-11-19T10:00:00Z"), ZoneOffset.UTC);

    @BeforeEach
    void init() {
        db = new Database(temp.resolve("practice"));
        auth = new Accounts(db);
        bank = new Problems(db, auth);
        study =
                new Practice(
                        db,
                        auth,
                        (l, s, t) -> {
                            calls.incrementAndGet();
                            return new Result(
                                    s.equals("right") ? "Accepted" : "Wrong Answer",
                                    "Test evaluation");
                        },
                        clock);
        auth.setup("Administrator", "10", password);
        auth.register("Student", "11", password);
        auth.register("Coach", "12", password);
        admin = auth.login("10", password).id();
        coach =
                auth.directory().stream()
                        .filter(a -> a.number().equals("12"))
                        .findFirst()
                        .orElseThrow()
                        .id();
        auth.changeRole(coach, Role.Coach);
        student = auth.login("11", password).id();
    }

    @Test
    void accountValidationAndSessionBoundaries() {
        assertThrows(IllegalArgumentException.class, () -> auth.register("", "13", password));
        assertThrows(IllegalArgumentException.class, () -> auth.register("Second", "11", password));
        assertThrows(IllegalStateException.class, () -> auth.setup("Duplicate", "88", password));
        assertThrows(IllegalStateException.class, () -> auth.directory());
        assertThrows(
                IllegalStateException.class, () -> auth.changeRole(student, Role.Administrator));
        assertThrows(IllegalStateException.class, () -> study.history(coach));
        assertThrows(IllegalStateException.class, () -> bank.publish(null));
        assertThrows(IllegalArgumentException.class, () -> auth.login("11", "wrong"));
        assertThrows(IllegalStateException.class, () -> bank.search("", "", ""));
        var other = new Accounts(db);
        other.login("10", password);
        auth.login("11", password);
        other.changeRole(student, Role.Coach);
        assertEquals(Role.Student, auth.require().role());
        auth.logout();
        assertThrows(IllegalStateException.class, auth::require);
        assertEquals(Role.Coach, auth.login("11", password).role());
        assertThrows(IllegalArgumentException.class, () -> other.changeRole(admin, Role.Student));
        var salts =
                db.transaction(
                        c ->
                                list(
                                        c,
                                        "SELECT salt FROM accounts",
                                        r -> HexFormat.of().formatHex(r.getBytes(1))));
        assertEquals(3, new HashSet<>(salts).size());
        assertTrue(
                db
                        .transaction(
                                c ->
                                        list(
                                                c,
                                                "SELECT digest FROM accounts",
                                                r -> r.getBytes(1).length))
                        .stream()
                        .allMatch(n -> n == 32));
    }

    @Test
    void filtersBookmarksPathsAndOwnership() {
        assertEquals(8, bank.search("", "", "").size());
        assertEquals(1, bank.search("Arrays", "Easy", "total").size());
        assertTrue(bank.search("Arrays", "Hard", "").isEmpty());
        assertEquals("Hard", bank.search("", "", "").get(7).difficulty());
        assertEquals(103, bank.open(103).item().id());
        assertFalse(bank.open(103).examples().isEmpty());
        assertTrue(bank.open(103).tests().isEmpty());
        assertThrows(NoSuchElementException.class, () -> bank.open(-10));
        bank.bookmark(103, true);
        bank.bookmark(103, true);
        assertEquals(1, bank.saved().size());
        auth.register("Other", "14", password);
        auth.login("14", password);
        assertTrue(bank.saved().isEmpty());
        auth.login("11", password);
        bank.bookmark(103, false);
        assertTrue(bank.saved().isEmpty());
        assertNotNull(bank.open(103));
    }

    @Test
    void contestLinksDeadlineAndDuplicateMembership() {
        Contest round = study.contests().get(0);
        long end = study.start(round);
        assertEquals(end, study.start(round));
        assertEquals(clock.millis() + 30 * 60_000L, end);
        assertEquals(3, study.contestProblems(round.id()).size());
        assertThrows(
                IllegalArgumentException.class,
                () -> study.submit(108, Language.JAVA, "right", round.id()));
        assertTrue(study.submit(103, Language.CPP, "right", round.id()).saved());
        var expired =
                new Practice(
                        db,
                        auth,
                        (l, s, t) -> fail("Expired attempt reached judge"),
                        Clock.fixed(Instant.ofEpochMilli(end), ZoneOffset.UTC));
        assertEquals(end, expired.start(round));
        assertThrows(
                IllegalArgumentException.class,
                () -> expired.submit(103, Language.JAVA, "right", round.id()));
        assertEquals(round.title(), study.history(student).get(0).contest());
        var team = study.teams().get(0);
        study.join(team.id());
        study.join(team.id());
        assertEquals(1, study.teams().stream().filter(Team::joined).count());
        auth.register("Peer", "13", password);
        auth.login("13", password);
        assertThrows(
                IllegalArgumentException.class,
                () -> study.submit(103, Language.JAVA, "right", round.id()));
        assertEquals(
                end + 60_000,
                new Practice(
                                db,
                                auth,
                                (l, s, t) -> fail(),
                                Clock.offset(clock, Duration.ofMinutes(1)))
                        .start(round));
        assertTrue(study.teams().stream().noneMatch(Team::joined));
    }

    @Test
    void attemptsSurviveRestartAndDistinctSolvedCount() {
        assertThrows(
                IllegalArgumentException.class, () -> study.submit(103, Language.JAVA, " ", null));
        assertThrows(
                IllegalArgumentException.class,
                () -> study.submit(999, Language.JAVA, "right", null));
        assertEquals(0, calls.get());
        for (String s : List.of("wrong", "right", "right"))
            study.submit(103, Language.JAVA, s, null);
        bank.bookmark(103, true);
        study.join(1);
        study.start(study.contests().get(0));
        auth.logout();
        var fresh = new Database(temp.resolve("practice"));
        var a = new Accounts(fresh);
        a.login("11", password);
        var p = new Practice(fresh, a, (l, s, t) -> fail(), clock);
        var history = p.history(student);
        assertEquals(3, history.size());
        assertEquals(
                1,
                history.stream()
                        .filter(x -> x.verdict().equals("Accepted"))
                        .map(x -> x.problem().id())
                        .distinct()
                        .count());
        assertEquals("wrong", history.get(2).source());
        assertNull(history.get(0).contest());
        assertEquals(clock.millis(), history.get(0).time());
        assertEquals(1, new Problems(fresh, a).saved().size());
        assertTrue(p.teams().get(0).joined());
        a.login("12", password);
        assertEquals(3, p.history(student).size());
        assertEquals(1, a.directory().size());
        assertThrows(IllegalArgumentException.class, () -> p.history(admin));
    }

    static Problem sample(long id, String title, String expected) {
        return new Problem(
                new Item(id, title, "Arrays", "Easy"),
                "Echo one integer.",
                "One integer.",
                "One integer.",
                "Read it.",
                "Print the integer.",
                List.of(new Sample("5", "5")),
                List.of(new Sample("8", expected)));
    }

    @Test
    void editsAtomicallyReplaceCasesAndPreserveIdentity() {
        auth.login("12", password);
        assertThrows(IllegalArgumentException.class, () -> bank.publish(sample(0, "", "8")));
        var invalid =
                new Problem(
                        new Item(0, "P", "New", "Easy"),
                        "Task",
                        "I",
                        "O",
                        "H",
                        "E",
                        List.of(new Sample("1", "1")),
                        List.of());
        assertThrows(IllegalArgumentException.class, () -> bank.publish(invalid));
        long id = bank.publish(sample(0, "Array Total", "8"));
        assertNotEquals(103, id);
        bank.publish(sample(id, "Revised", "9"));
        assertEquals("9", bank.open(id).tests().get(0).output());
        db.transaction(
                c -> update(c, "ALTER TABLE cases ADD CHECK(expected <> 'trigger-save-failure')"));
        assertThrows(
                Database.StorageError.class,
                () -> bank.publish(sample(id, "Unsaved title", "trigger-save-failure")));
        assertEquals("Revised", bank.open(id).item().title());
        assertEquals("9", bank.open(id).tests().get(0).output());
        auth.login("11", password);
        var linked =
                new Practice(
                        db,
                        auth,
                        (l, s, t) -> {
                            assertEquals(List.of(new Sample("8", "9")), t);
                            return new Result("Wrong Answer", "Mismatch");
                        },
                        clock);
        assertTrue(linked.submit(id, Language.PYTHON, "right", null).saved());
    }

    @Test
    void failedSavesAndCheckingErrorsAreVisible() {
        db.transaction(c -> update(c, "ALTER TABLE accounts ADD CHECK(name <> 'Forbidden')"));
        assertThrows(Database.StorageError.class, () -> auth.register("Forbidden", "14", password));
        var broken =
                new Practice(
                        db,
                        auth,
                        (l, s, t) -> {
                            throw new IllegalStateException();
                        },
                        clock);
        var failed = broken.submit(103, Language.JAVA, "right", null);
        assertEquals("Checking failed", failed.result().verdict());
        db.transaction(c -> update(c, "ALTER TABLE attempts ADD CHECK(source <> 'blocked')"));
        var receipt = study.submit(103, Language.JAVA, "blocked", null);
        assertFalse(receipt.saved());
        assertEquals(1, study.history(student).size());
    }

    @Test
    void filteredThousandProblemBank() {
        db.transaction(
                c ->
                        update(
                                c,
                                """
INSERT INTO problems(title,topic,difficulty,statement,inputs,outputs,hint,explanation)
SELECT CONCAT('Training ',X),'Arrays','Easy','s','i','o','h','e' FROM SYSTEM_RANGE(1,992)
"""));
        assertEquals(1000, bank.search("", "", "").size());
        long start = System.nanoTime();
        var found = bank.search("Arrays", "Easy", "");
        long ms = (System.nanoTime() - start) / 1_000_000;
        System.out.println(
                "1,000 problems: matching rows="
                        + found.size()
                        + ", query and mapping="
                        + ms
                        + " ms");
        assertEquals(993, found.size());
        assertTrue(ms < 3000);
        assertEquals(found, bank.search("Arrays", "Easy", ""));
    }
}
