package edu.aqu.coding;

import static org.junit.jupiter.api.Assertions.*;

import edu.aqu.coding.data.Database;
import edu.aqu.coding.judge.*;
import edu.aqu.coding.model.Models.*;
import edu.aqu.coding.service.*;
import edu.aqu.coding.ui.Desktop;

import javafx.application.Platform;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.*;
import java.time.Clock;
import java.util.concurrent.*;

class DesktopTest {
    @TempDir Path temp;
    Stage stage;
    static final String PASS = "student-pass";

    static <T> T fx(Callable<T> action) throws Exception {
        var task = new FutureTask<>(action);
        Platform.runLater(task);
        return task.get(20, TimeUnit.SECONDS);
    }

    @BeforeAll
    static void toolkit() throws Exception {
        var ready = new CountDownLatch(1);
        Platform.startup(
                () -> {
                    Platform.setImplicitExit(false);
                    ready.countDown();
                });
        assertTrue(ready.await(15, TimeUnit.SECONDS));
    }

    @BeforeEach
    void open() throws Exception {
        fx(
                () -> {
                    var db = new Database(temp.resolve("app"));
                    var auth = new Accounts(db);
                    var desktop =
                            new Desktop(
                                    stage = new Stage(),
                                    auth,
                                    new Problems(db, auth),
                                    new Practice(db, auth, new DockerJudge(), Clock.systemUTC()));
                    desktop.show();
                    return null;
                });
    }

    @AfterEach
    void close() throws Exception {
        fx(
                () -> {
                    stage.close();
                    return null;
                });
    }

    Parent root() {
        var root = stage.getScene().getRoot();
        root.applyCss();
        root.layout();
        return root;
    }

    void click(String text) {
        var b =
                root().lookupAll(".button").stream()
                        .filter(n -> n instanceof Button v && v.getText().equals(text))
                        .map(Button.class::cast)
                        .findFirst()
                        .orElseThrow(() -> new AssertionError("Missing button: " + text));
        assertFalse(b.isDisabled(), text);
        b.fire();
    }

    void type(String id, String value) {
        ((TextInputControl) root().lookup("#" + id)).setText(value);
    }

    void choose(String id, Object value) {
        ComboBox<?> c = (ComboBox<?>) root().lookup("#" + id);
        int i = c.getItems().indexOf(value);
        assertTrue(i >= 0);
        c.getSelectionModel().select(i);
    }

    boolean has(String text) {
        return root().lookupAll(".label").stream()
                .filter(Label.class::isInstance)
                .map(Label.class::cast)
                .anyMatch(l -> l.isVisible() && l.getText() != null && l.getText().contains(text));
    }

    void enroll(String name, String number) {
        click("Create student account");
        type("name", name);
        type("number", number);
        type("password", PASS);
        click("Create account");
        assertTrue(has("Account created."), "Missing on screen: Account created.");
    }

    void signIn(String number) {
        type("number", number);
        type("password", PASS);
        click("Sign in");
    }

    @Test
    void studentCoachAndAdminFromFirstLaunchToReopen() throws Exception {
        fx(
                () -> {
                    type("name", "Local Admin");
                    type("number", "101");
                    type("password", PASS);
                    click("Create administrator");
                    enroll("Practice Student", "102");
                    enroll("Practice Coach", "103");
                    signIn("101");
                    ComboBox<?> users = (ComboBox<?>) root().lookup("#accounts");
                    choose(
                            "accounts",
                            users.getItems().stream()
                                    .map(Account.class::cast)
                                    .filter(a -> a.number().equals("103"))
                                    .findFirst()
                                    .orElseThrow());
                    choose("role", Role.Coach);
                    click("Save role");
                    assertTrue(has("Role saved"), "Missing on screen: Role saved");
                    click("Log out");
                    signIn("102");
                    assertTrue(has("Problem bank"), "Missing on screen: Problem bank");
                    type("search", "no such title");
                    assertTrue(
                            has("No matching problems."),
                            "Missing on screen: No matching problems.");
                    type("search", "First Sum");
                    click("Open problem");
                    assertTrue(has("First Sum"), "Missing on screen: First Sum");
                    click("Save problem");
                    click("Saved problems");
                    click("Open problem");
                    var pane =
                            (TitledPane)
                                    root().lookupAll(".titled-pane").stream()
                                            .filter(n -> ((TitledPane) n).getText().equals("Hint"))
                                            .findFirst()
                                            .orElseThrow();
                    pane.setAnimated(false);
                    pane.setExpanded(true);
                    assertTrue(has("Read both integers"), "Missing on screen: Read both integers");
                    choose("language", Language.JAVA);
                    type(
                            "source",
                            Files.readString(
                                    Path.of("src/test/resources/solutions/101/Main.java")));
                    click("Submit");
                    assertTrue(
                            has("Checking your solution"),
                            "Missing on screen: Checking your solution");
                    return null;
                });
        long limit = System.nanoTime() + TimeUnit.SECONDS.toNanos(95);
        while (!fx(() -> has("Saved to your history.")) && System.nanoTime() < limit)
            Thread.sleep(100);
        fx(
                () -> {
                    assertTrue(has("Accepted"), "Missing on screen: Accepted");
                    click("Progress");
                    assertTrue(has("1 problem solved"), "Missing on screen: 1 problem solved");
                    click("Teams");
                    click("Join team");
                    assertTrue(
                            root().lookupAll(".button").stream()
                                    .anyMatch(
                                            n ->
                                                    n instanceof Button b
                                                            && b.getText().equals("Joined")));
                    click("Contests");
                    click("Start or resume");
                    assertTrue(has("Time remaining"), "Missing on screen: Time remaining");
                    click("Learning path");
                    assertTrue(
                            has("Competition preparation"),
                            "Missing on screen: Competition preparation");
                    click("Log out");
                    signIn("103");
                    click("Student review");
                    click("View progress");
                    assertTrue(has("1 problem solved"), "Missing on screen: 1 problem solved");
                    click("Problem library");
                    click("New problem");
                    type("problem-title", "Echo");
                    click("Save problem");
                    assertTrue(has("Enter the topic"), "Missing on screen: Enter the topic");
                    assertEquals("Echo", ((TextField) root().lookup("#problem-title")).getText());
                    type("problem-topic", "Basics");
                    type("statement", "Echo one number.");
                    type("input-rules", "One number.");
                    type("output-rules", "Print it.");
                    type("hint", "Read it.");
                    type("explanation", "Write the number to standard output.");
                    for (String id :
                            new String[] {"example-in", "example-out", "test-in", "test-out"})
                        type(id, "1");
                    click("Save problem");
                    assertTrue(has("Problem saved."), "Missing on screen: Problem saved.");
                    type("search", "Echo");
                    click("Edit selected problem");
                    type("problem-title", "Revised Echo");
                    click("Save problem");
                    assertTrue(has("Problem saved."), "Missing on screen: Problem saved.");
                    click("Log out");
                    return null;
                });
        close();
        open();
        fx(
                () -> {
                    signIn("102");
                    type("search", "Revised Echo");
                    click("Open problem");
                    assertTrue(has("Echo one number."), "Missing on screen: Echo one number.");
                    click("Progress");
                    assertTrue(has("1 problem solved"), "Missing on screen: 1 problem solved");
                    click("Saved problems");
                    click("Open problem");
                    assertTrue(has("First Sum"), "Missing on screen: First Sum");
                    click("Remove from saved");
                    click("Saved problems");
                    assertTrue(
                            has("No saved problems yet"),
                            "Missing on screen: No saved problems yet");
                    click("Log out");
                    assertTrue(has("Welcome back"), "Missing on screen: Welcome back");
                    return null;
                });
    }
}
