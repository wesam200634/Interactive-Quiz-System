import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt(), m = in.nextInt();
        List<List<Integer>> edges = new ArrayList<>();
        for (int i = 0; i < n; i++) edges.add(new ArrayList<>());
        for (int i = 0; i < m; i++) {
            int left = in.nextInt() - 1, right = in.nextInt() - 1;
            edges.get(left).add(right);
            edges.get(right).add(left);
        }
        boolean[] seen = new boolean[n];
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        int groups = 0;
        for (int start = 0; start < n; start++) {
            if (seen[start]) continue;
            groups++;
            seen[start] = true;
            stack.push(start);
            while (!stack.isEmpty()) {
                for (int next : edges.get(stack.pop())) {
                    if (!seen[next]) {
                        seen[next] = true;
                        stack.push(next);
                    }
                }
            }
        }
        System.out.println(groups);
    }
}
