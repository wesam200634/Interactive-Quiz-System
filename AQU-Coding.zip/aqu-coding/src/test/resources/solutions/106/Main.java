import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt(), queries = in.nextInt();
        long[] prefix = new long[n + 1];
        for (int i = 1; i <= n; i++) prefix[i] = prefix[i - 1] + in.nextInt();
        StringBuilder answers = new StringBuilder();
        for (int i = 0; i < queries; i++) {
            int left = in.nextInt(), right = in.nextInt();
            answers.append(prefix[right] - prefix[left - 1]).append('\n');
        }
        System.out.print(answers);
    }
}
