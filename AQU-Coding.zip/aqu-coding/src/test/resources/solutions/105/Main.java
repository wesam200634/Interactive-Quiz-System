import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] times = new int[in.nextInt()];
        for (int i = 0; i < times.length; i++) times[i] = in.nextInt();
        Arrays.sort(times);
        System.out.println(times[times.length / 2]);
    }
}
