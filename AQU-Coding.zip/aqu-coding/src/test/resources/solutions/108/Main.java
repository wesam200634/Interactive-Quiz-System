import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt(), budget = in.nextInt();
        int[] best = new int[budget + 1];
        for (int i = 0; i < n; i++) {
            int duration = in.nextInt(), points = in.nextInt();
            for (int t = budget; t >= duration; t--) {
                best[t] = Math.max(best[t], best[t - duration] + points);
            }
        }
        System.out.println(best[budget]);
    }
}
