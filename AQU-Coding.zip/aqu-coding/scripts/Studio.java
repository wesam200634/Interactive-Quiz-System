import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Cross-platform entry point. Run from the project root with a JDK 17 or newer. */
class Studio {
    static final Path ROOT = Path.of("").toAbsolutePath();
    static final String SEP = File.pathSeparator;
    static final String PLATFORM = platform();
    static final Path FX = ROOT.resolve("lib").resolve(PLATFORM);
    static final Path JAR = ROOT.resolve("dist/aqu-coding.jar");

    static String platform() {
        String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
        String arch = System.getProperty("os.arch");
        if (os.startsWith("mac")) return arch.contains("aarch64") ? "mac-aarch64" : "mac";
        if (!(arch.equals("amd64") || arch.equals("x86_64")))
            throw new IllegalArgumentException(
                    "This desktop bundle supports x64 Windows/Linux and x64/ARM64 macOS.");
        if (os.startsWith("win")) return "win";
        if (os.startsWith("linux")) return "linux";
        throw new IllegalArgumentException("Unsupported operating system: " + os);
    }

    static String tool(String name) {
        return Path.of(
                        System.getProperty("java.home"),
                        "bin",
                        name + (PLATFORM.equals("win") ? ".exe" : ""))
                .toString();
    }

    static void exec(List<String> cmd) throws Exception {
        int status = new ProcessBuilder(cmd).inheritIO().start().waitFor();
        if (status != 0) throw new IOException(cmd.get(0) + " exited with status " + status);
    }

    static void compile(String src, Path out, String cp) throws Exception {
        Files.createDirectories(out);
        var cmd =
                new ArrayList<>(
                        List.of(
                                tool("javac"),
                                "--release",
                                "17",
                                "-encoding",
                                "UTF-8",
                                "-cp",
                                cp,
                                "-d",
                                out.toString()));
        try (var paths = Files.walk(ROOT.resolve(src))) {
            paths.filter(p -> p.toString().endsWith(".java"))
                    .sorted()
                    .forEach(p -> cmd.add(p.toString()));
        }
        exec(cmd);
    }

    static void build() throws Exception {
        Path classes = ROOT.resolve("build/classes");
        compile("src/main/java", classes, FX.resolve("*") + SEP + "lib/common/*");
        Files.createDirectories(JAR.getParent());
        exec(
                List.of(
                        tool("jar"),
                        "--create",
                        "--file",
                        JAR.toString(),
                        "--main-class",
                        "edu.aqu.coding.Main",
                        "-C",
                        classes.toString(),
                        ".",
                        "-C",
                        "src/main/resources",
                        "."));
        System.out.println("Built " + JAR);
    }

    static void run(String[] args) throws Exception {
        if (!Files.exists(JAR)) build();
        var cmd = new ArrayList<>(List.of(tool("java")));
        if (args.length > 1) cmd.add("-Daqu.data=" + Path.of(args[1]).toAbsolutePath());
        cmd.addAll(
                List.of(
                        "--module-path",
                        FX.toString(),
                        "--add-modules",
                        "javafx.controls",
                        "-cp",
                        JAR + SEP + "lib/common/*",
                        "edu.aqu.coding.Main"));
        exec(cmd);
    }

    static void tests() throws Exception {
        build();
        Path out = ROOT.resolve("build/tests");
        String cp = JAR + SEP + FX.resolve("*") + SEP + "lib/common/*" + SEP + "lib/test/*";
        compile("src/test/java", out, cp);
        exec(
                List.of(
                        tool("java"),
                        "-Dglass.platform=Monocle",
                        "-Dmonocle.platform=Headless",
                        "-Dprism.order=sw",
                        "-Djava.awt.headless=true",
                        "-cp",
                        out + SEP + cp,
                        "org.junit.platform.console.ConsoleLauncher",
                        "execute",
                        "--disable-ansi-colors",
                        "--fail-if-no-tests",
                        "--select-package",
                        "edu.aqu.coding",
                        "--details",
                        "tree"));
    }

    static void setupJudge() throws Exception {
        Process info =
                new ProcessBuilder("docker", "info", "--format", "{{.Architecture}}")
                        .redirectError(ProcessBuilder.Redirect.INHERIT)
                        .start();
        String arch =
                new String(
                                info.getInputStream().readAllBytes(),
                                java.nio.charset.StandardCharsets.UTF_8)
                        .strip();
        if (info.waitFor() != 0)
            throw new IOException("Start your local Docker engine before preparing the judge.");
        Path archive = ROOT.resolve("judge/images-linux-amd64.tar.gz");
        if ((arch.equals("x86_64") || arch.equals("amd64")) && Files.exists(archive)) {
            exec(List.of("docker", "load", "-i", archive.toString()));
            System.out.println("Loaded all three judge images from the offline bundle.");
            return;
        }
        exec(List.of("docker", "pull", "amazoncorretto:17-alpine"));
        exec(List.of("docker", "pull", "python:3.12-alpine"));
        exec(List.of("docker", "build", "-t", "aqu-cpp:1", "judge"));
        System.out.println("The three local judge images are ready.");
    }

    public static void main(String[] args) {
        try {
            if (!Files.isDirectory(FX))
                throw new IOException("Open a terminal in the extracted aqu-coding directory.");
            switch (args.length == 0 ? "run" : args[0]) {
                case "build" -> build();
                case "run" -> run(args);
                case "test" -> tests();
                case "judge-setup" -> setupJudge();
                default ->
                        throw new IllegalArgumentException(
                                "Usage: java scripts/Studio.java run [database-path] | build | test"
                                        + " | judge-setup");
            }
        } catch (Exception e) {
            System.err.println("AQU Coding: " + e.getMessage());
            System.exit(1);
        }
    }
}
